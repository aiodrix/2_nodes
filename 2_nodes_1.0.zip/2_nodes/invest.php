<?php error_reporting(0); 
session_start();

$user = $_SESSION['user'];

if (!$user){echo "<script>alert('You are not logged!');</script>";}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invest Credits</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .update-form {
            background-color: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #666;
            text-align: left;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s, transform 0.3s;
        }

        button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.3s ease-in-out;
        }

        .modal-button {
            background-color: #28a745;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px;
            font-size: 14px;
            transition: background-color 0.3s;
        }

        .modal-button:hover {
            background-color: #218838;
        }

        .modal-button:last-child {
            background-color: #dc3545;
        }

        .modal-button:last-child:hover {
            background-color: #c82333;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
    </style>
</head>
<body>
  
    <div class="update-form">
        <h2>Invest Credits</h2>
        <form id="investForm" action="invest_credits.php" method="post">
            <label for="investAmount">Investment Amount:</label>
            <input type="number" id="investAmount" name="investAmount" min="1" max="<?php echo $userData['credits']; ?>" required>

            <label for="filehash">Filehash:</label>
            <input type="text" id="filehash" name="filehash" value="<?php echo $_GET['fileHash']; ?>" required>
            <button type="button" onclick="showConfirmationModal()">Invest Credits</button>
        </form>
    </div>

    <!-- Modal -->
    <div id="confirmationModal" class="modal">
        <div class="modal-content">
            <p>Are you sure you want to invest credits?</p>
            <button class="modal-button" onclick="proceedInvest()">Yes</button>
            <button class="modal-button" onclick="hideModal()">No</button>
        </div>
    </div>

    <script>
        function showConfirmationModal() {
            var modal = document.getElementById('confirmationModal');
            modal.style.display = 'flex';
        }

        function hideModal() {
            var modal = document.getElementById('confirmationModal');
            modal.style.display = 'none';
        }

        function proceedInvest() {
            document.getElementById('investForm').submit();
        }
    </script>
</body>
</html>