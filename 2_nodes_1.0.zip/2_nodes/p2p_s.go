package main

import (
	"encoding/binary"
	"fmt"
	"io"
	"io/ioutil"
	"net"
	"os"
	"path/filepath"
)

const (
	serverDir         = "server_files"
	maxFileNameLength = 255  // Maximum reasonable length for a file name
)

func handleUpload(conn net.Conn) {
	defer conn.Close()
	var fileName string
	_, err := fmt.Fscanln(conn, &fileName)
	if err != nil {
		fmt.Println("Failed to read file name:", err)
		return
	}

	filePath := filepath.Join(serverDir, fileName)
	if _, err := os.Stat(filePath); err == nil {
		fmt.Fprintln(conn, "EXISTS")
		fmt.Printf("File %s already exists on server\n", fileName)
		return
	}

	fmt.Fprintln(conn, "OK")

	file, err := os.Create(filePath)
	if err != nil {
		fmt.Fprintf(conn, "Error: %v\n", err)
		return
	}
	defer file.Close()

	_, err = io.Copy(file, conn)
	if err != nil {
		fmt.Println("Failed to receive file:", err)
		return
	}

	fmt.Printf("File %s received successfully\n", fileName)
}

func handleDownload(conn net.Conn) {
	defer conn.Close()
	files, err := ioutil.ReadDir(serverDir)
	if err != nil {
		fmt.Fprintf(conn, "Error: %v\n", err)
		return
	}

	for _, file := range files {
		if !file.IsDir() {
			filePath := filepath.Join(serverDir, file.Name())
			file, err := os.Open(filePath)
			if err != nil {
				fmt.Println("Failed to open file:", err)
				return
			}
			defer file.Close()

			fileInfo, err := file.Stat()
			if err != nil {
				fmt.Println("Failed to get file info:", err)
				return
			}

			fileNameLength := int64(len(file.Name()))
			if fileNameLength > maxFileNameLength {
				fmt.Println("File name too long, skipping:", file.Name())
				continue
			}

			fileSize := fileInfo.Size()

			binary.Write(conn, binary.LittleEndian, fileNameLength)
			conn.Write([]byte(file.Name()))
			binary.Write(conn, binary.LittleEndian, fileSize)

			_, err = io.Copy(conn, file)
			if err != nil {
				fmt.Println("Failed to send file:", err)
				return
			}
		}
	}
}

func handleConnection(conn net.Conn) {
	defer conn.Close()
	var action string
	_, err := fmt.Fscanln(conn, &action)
	if err != nil {
		fmt.Println("Failed to read action:", err)
		return
	}

	switch action {
	case "UPLOAD":
		handleUpload(conn)
	case "DOWNLOAD":
		handleDownload(conn)
	default:
		fmt.Fprintf(conn, "Unknown action: %s\n", action)
	}
}

func startServer(address string) {
	listener, err := net.Listen("tcp", address)
	if err != nil {
		fmt.Printf("Failed to start server: %v\n", err)
		return
	}
	defer listener.Close()

	fmt.Println("Server is listening on", address)
	for {
		conn, err := listener.Accept()
		if err != nil {
			fmt.Println("Failed to accept connection:", err)
			continue
		}
		go handleConnection(conn)
	}
}

func main() {
	if err := os.MkdirAll(serverDir, 0755); err != nil {
		fmt.Printf("Failed to create server directory: %v\n", err)
		return
	}

	startServer(":8081")  // Replace with the desired port number
}