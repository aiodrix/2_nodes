package main

import (
	"bufio"
	"encoding/binary"
	"fmt"
	"io"
	"io/ioutil"
	"net"
	"os"
	"path/filepath"
	"strings"
)

const (
	clientDir   = "files"
	downloadDir = "downloads"
	serversFile = "p2p_servers.txt"
)

func uploadFiles(serverAddress string) error {
	files, err := ioutil.ReadDir(clientDir)
	if err != nil {
		return fmt.Errorf("failed to read client directory: %w", err)
	}

	for _, file := range files {
		if !file.IsDir() {
			filePath := filepath.Join(clientDir, file.Name())
			conn, err := net.Dial("tcp", serverAddress)
			if err != nil {
				return fmt.Errorf("failed to connect to server: %w", err)
			}
			defer conn.Close()

			fmt.Fprintln(conn, "UPLOAD")
			fmt.Fprintln(conn, file.Name())

			file, err := os.Open(filePath)
			if err != nil {
				return fmt.Errorf("failed to open file: %w", err)
			}
			defer file.Close()

			_, err = io.Copy(conn, file)
			if err != nil {
				return fmt.Errorf("failed to upload file: %w", err)
			}

			fmt.Printf("File %s uploaded successfully to %s\n", file.Name(), serverAddress)
		}
	}
	return nil
}

func downloadFiles(serverAddress string) error {
	conn, err := net.Dial("tcp", serverAddress)
	if err != nil {
		return fmt.Errorf("failed to connect to server: %w", err)
	}
	defer conn.Close()

	fmt.Fprintln(conn, "DOWNLOAD")

	if err := os.MkdirAll(downloadDir, 0755); err != nil {
		return fmt.Errorf("failed to create download directory: %w", err)
	}

	for {
		// Read file name length
		var fileNameLength int64
		err := binary.Read(conn, binary.LittleEndian, &fileNameLength)
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("failed to read file name length: %w", err)
		}

		// Read file name
		fileName := make([]byte, fileNameLength)
		_, err = io.ReadFull(conn, fileName)
		if err != nil {
			return fmt.Errorf("failed to read file name: %w", err)
		}

		// Read file size
		var fileSize int64
		err = binary.Read(conn, binary.LittleEndian, &fileSize)
		if err != nil {
			return fmt.Errorf("failed to read file size: %w", err)
		}

		filePath := filepath.Join(downloadDir, string(fileName))
		file, err := os.Create(filePath)
		if err != nil {
			return fmt.Errorf("failed to create file: %w", err)
		}
		defer file.Close()

		// Read file data
		_, err = io.CopyN(file, conn, fileSize)
		if err != nil {
			return fmt.Errorf("failed to download file: %w", err)
		}

		fmt.Printf("File %s downloaded successfully from %s\n", string(fileName), serverAddress)
	}
	return nil
}

func readServerAddresses(fileName string) ([]string, error) {
	file, err := os.Open(fileName)
	if err != nil {
		return nil, fmt.Errorf("failed to open servers file: %w", err)
	}
	defer file.Close()

	var addresses []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		address := strings.TrimSpace(scanner.Text())
		if address != "" {
			addresses = append(addresses, address)
		}
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("failed to read servers file: %w", err)
	}

	return addresses, nil
}

func main() {
	addresses, err := readServerAddresses(serversFile)
	if err != nil {
		fmt.Printf("Error reading server addresses: %v\n", err)
		return
	}

	for _, address := range addresses {
		fmt.Printf("Connecting to server %s\n", address)

		fmt.Println("Uploading files...")
		if err := uploadFiles(address); err != nil {
			fmt.Printf("Error uploading files to %s: %v\n", address, err)
			continue
		}

		fmt.Println("Downloading files...")
		if err := downloadFiles(address); err != nil {
			fmt.Printf("Error downloading files from %s: %v\n", address, err)
			continue
		}
	}
}