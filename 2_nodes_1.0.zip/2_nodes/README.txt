You may share, use, or edit our software for personal or commercial purposes. 
However, for commercial use, you must purchase a license, pay 1% of the profit, or contribute to the code after one year of use.
For more information, read 'doc.html' or contact us.

We are not responsible for any losses or damages caused by the use of the software, nor for its use by third parties or others.