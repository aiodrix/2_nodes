package main

import (
	"bytes"
	"fmt"
        "io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func main() {
	http.HandleFunc("/upload", uploadHandler)
	http.ListenAndServe(":8080", nil)
}

func uploadHandler(w http.ResponseWriter, r *http.Request) {
/*/
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}
/*/
	uploadURLs := r.FormValue("upload_urls")
	if uploadURLs == "" {
		http.Error(w, "Please enter at least one URL where the files will be sent.", http.StatusBadRequest)
		return
	}

	urls := strings.Split(uploadURLs, "\n")
	directory := "files_test"

	files, err := ioutil.ReadDir(directory)
	if err != nil {
		http.Error(w, "Unable to read files directory", http.StatusInternalServerError)
		return
	}

	for _, file := range files {
		if file.IsDir() {
			continue
		}

		filePath := filepath.Join(directory, file.Name())

		for _, url := range urls {
			url = strings.TrimSpace(url)
			if url == "" {
				continue
			}

			err := uploadFile(url, filePath)
			if err != nil {
				fmt.Fprintf(w, "Error sending file %s to %s: %v<br>", file.Name(), url, err)
			} else {
				fmt.Fprintf(w, "File %s uploaded successfully to %s<br>", file.Name(), url)
			}
		}
	}
}

func uploadFile(url string, filePath string) error {
	file, err := os.Open(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)

	part, err := writer.CreateFormFile("uploaded_file", filepath.Base(filePath))
	if err != nil {
		return err
	}

	_, err = io.Copy(part, file)
	if err != nil {
		return err
	}

	err = writer.Close()
	if err != nil {
		return err
	}

	req, err := http.NewRequest(http.MethodPost, url, body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", writer.FormDataContentType())

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		respBody, _ := ioutil.ReadAll(resp.Body)
		return fmt.Errorf("received non-200 response: %d - %s", resp.StatusCode, string(respBody))
	}

	return nil
}
