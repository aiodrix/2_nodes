<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>File Upload Form</title>
</head>
<body>
<h1>Upload File</h1>
<form action="http://localhost:8080/upload" method="post" enctype="multipart/form-data">
    <label for="urls">Enter the URLs where the file will be sent (one URL per line):</label><br>
    <textarea id="urls" name="upload_urls" rows="5" cols="50" placeholder="http://example.com/receiver.php
http://example.net/receiver.php"></textarea><br><br>
    <input type="submit" value="Upload Files">
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["upload_urls"])) {
        $directory = 'files_test/';
        $files = scandir($directory);
        $urls = explode("\n", $_POST["upload_urls"]);

        foreach ($files as $file) {
            // Skip the current directory (.) and parent directory (..)
            if ($file === '.' || $file === '..') {
                continue;
            }

            $filePath = $directory . $file;
            $fileType = mime_content_type($filePath);

            foreach ($urls as $url) {
                $url = trim($url);
                if (!empty($url)) {
                    // Create a new cURL handle for each URL
                    $curl = curl_init();

                    // Set the cURL options
                    curl_setopt($curl, CURLOPT_URL, $url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, [
                        'uploaded_file' => new CURLFile($filePath, $fileType, $file)
                    ]);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                    // Execute the cURL request
                    $response = curl_exec($curl);

                    // Check for errors
                    if ($response === false) {
                        echo "Error sending file $file to $url: " . curl_error($curl) . "<br>";
                    } else {
                        echo "File $file uploaded successfully to $url<br>";
                    }

                    // Close cURL session
                    curl_close($curl);
                }
            }
        }
    } else {
        echo "Please enter at least one URL where the files will be sent.";
    }
}
?>

</body>
</html>
</body>
</html>