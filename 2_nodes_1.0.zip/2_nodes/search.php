<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aio2nodes";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Create table (if not exists)
$sql = "CREATE TABLE IF NOT EXISTS files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filehash VARCHAR(255) NOT NULL,
  filename VARCHAR(255) NOT NULL,
  filemime VARCHAR(255) NOT NULL,
  filesize VARCHAR(255) NOT NULL,
  fileextension VARCHAR(50) NOT NULL,
  date DATE NOT NULL,
  wallet VARCHAR(255) NOT NULL,
  url VARCHAR(255) DEFAULT NULL
)";

if (mysqli_query($conn, $sql)) {
  //echo "Table files created successfully (or already exists)";
} else {
  echo "Error creating table: " . mysqli_error($conn);
}

// Handle search if search parameter is set in either GET or POST
$searchTerm = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
  $searchTerm = mysqli_real_escape_string($conn, $_POST['search']);
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
  $searchTerm = mysqli_real_escape_string($conn, $_GET['search']);
}

if (!empty($searchTerm)) {
  // Build search query
  $sql = "SELECT * FROM files WHERE filehash LIKE '%$searchTerm%' OR filename LIKE '%$searchTerm%' OR fileextension LIKE '%$searchTerm%' OR date LIKE '%$searchTerm%' OR wallet LIKE '%$searchTerm%'";

  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
    echo "<h2>Search Results</h2>";
    echo "<table>
      <tr>
        <th>ID</th>
        <th>File Hash</th>
        <th>Filename</th>
        <th>Extension</th>
        <th>Date</th>
        <th>Invest</th>
      </tr>";
    while($row = mysqli_fetch_assoc($result)) {
      $rowFileHash = $row["filehash"];
      $rowURL = $row["url"];
      $rowFileName = $row["filename"];
      $rowExtension = $row["fileextension"];

      $localFilePath = 'files/' . $rowFileHash . "." . $rowExtension;

      echo "<tr>
        <td>" . $row["id"] . "</td>
        <td>" . "<a href='$localFilePath' target='_blank'>$rowFileHash</a>" . "</td>
        <td>" . "<a href='$rowURL' target='_blank'>$rowFileName</a>" . "</td>
        <td>" . $row["fileextension"] . "</td>
        <td>" . $row["date"] . "</td>
        <td>" . "<a href='invest.php?fileHash=$rowFileHash' class='buttonStyle'>invest</a>" . "</td>
      </tr>";
    }
    echo "</table>";
  } else {
    echo "No results found!";
  }
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search Files</title>
  <style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
  }

  h1 {
    text-align: center;
    margin-bottom: 20px;
  }

  form {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
  }

  label {
    margin-bottom: 5px;
  }

  /* Search field styling */
  input[type="text"] {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 250px;
  }

  /* Button styling */
  button {
    padding: 10px 20px;
    background-color: #4CAF50; /* Green */
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  button:hover {
    background-color: #45a049; /* Green hover */
  }

  table {
    border-collapse: collapse;
    width: 100%;
  }

  th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: left;
  }

  th {
    background-color: #f2f2f2;
  }

.buttonStyle {
  background-color: #CCC;  /* Adjust background color */
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: all 0.2s ease-in-out;  /* Define transition for smooth animation */
  text-decoration: none
}

.buttonStyle:hover {
  background-color: #2980b9;  /* Adjust hover background color */
  transform: scale(1.05);  /* Define hover animation (scale up slightly) */
}
  </style>
</head>
<body>

  <form action="" method="post">
    <input type="text" id="search" name="search" required> &nbsp; 
    <button type="submit">Search</button>
  </form>
</body>
</html>