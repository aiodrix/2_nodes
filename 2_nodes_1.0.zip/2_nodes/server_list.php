<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>File Upload Form</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f3f3f3;
}

.container {
    max-width: 600px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1, h4 {
    text-align: center;
    margin-bottom: 20px;
}

form {
    margin-bottom: 20px;
}

label {
    font-weight: bold;
}

input[type="text"], input[type="file"], textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

textarea {
    height: 100px;
}

button {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    border-radius: 4px;
}

button:hover {
    background-color: #0056b3;
}

.alert {
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
}

.alert-warning {
    color: #856404;
    background-color: #fff3cd;
    border-color: #ffeeba;
}

.alert-success {
    color: #155724;
    background-color: #d4edda;
    border-color: #c3e6cb;
}

.alert-danger {
    color: #721c24;
    background-color: #f8d7da;
    border-color: #f5c6cb;
}

.result-item {
    margin-bottom: 10px;
}

.result-item strong {
    display: block;
    margin-bottom: 5px;
}

.result-item a {
    color: #007bff;
    text-decoration: none;
}

.result-item a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<div class="container">
    <h1>Server indexation</h1>
    <div class="forms">
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Submit your server manually</h4>
            </div>
            <div class="card-body">
                <form action="server_list.php" method="post">
                    <div class="mb-3">
                        <label for="url" class="form-label">Server URL</label>
                        <input type="text" id="url" name="url" required>
                    </div>
                    <div class="mb-3">
                        <label for="contents" class="form-label">About</label>
                        <textarea id="contents" name="contents" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Search</h4>
            </div>
            <div class="card-body">
                <form action="server_list.php" method="get">
                    <div class="mb-3">
                        <input type="text" id="search" name="search" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
        </div>
    </div>
    <div class="results">
        <div class="search-results">
            <?php
            // Database connection details
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "aio2nodes";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Create table if it doesn't exist
            $sql = "CREATE TABLE IF NOT EXISTS servers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                url VARCHAR(255) UNIQUE,
                contents TEXT,
                ip_hash CHAR(32) UNIQUE
            )";

            if ($conn->query($sql) === FALSE) {
                echo "<div class='alert alert-danger'>Error creating table: " . $conn->error . "</div>";
            }

            // Get user IP address and hash it
            $user_ip = $_SERVER['REMOTE_ADDR'];
            $ip_hash = md5($user_ip);

            // Handle form submission for adding data
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['url']) && isset($_POST['contents'])) {
                $url = $_POST['url'];
                $contents = $_POST['contents'];

                // Check for duplicate URL or IP hash
                $stmt = $conn->prepare("SELECT COUNT(*) FROM servers WHERE url = ? OR ip_hash = ?");
                $stmt->bind_param("ss", $url, $ip_hash);
                $stmt->execute();
                $stmt->bind_result($count);
                $stmt->fetch();
                $stmt->close();

                if ($count > 0) {
                    echo "<div class='alert alert-warning'>Duplicate entry for URL or IP detected</div>";
                } else {
                    // Prepare and bind
                    $stmt = $conn->prepare("INSERT INTO servers (url, contents, ip_hash) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $url, $contents, $ip_hash);

                    // Execute the statement
                    if ($stmt->execute()) {
                        echo "<div class='alert alert-success'>New record created successfully</div>";
                    } else {
                        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
                    }

                    // Close the statement
                    $stmt->close();
                }
            } else {
                echo "<br><br><br>";
            }

            // Handle search query
            if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
                $search = $_GET['search'];

                // Prepare and bind
                $stmt = $conn->prepare("SELECT id, date, url, contents FROM servers WHERE contents LIKE ?");
                $searchTerm = "%" . $search . "%";
                $stmt->bind_param("s", $searchTerm);

                // Execute the statement
                $stmt->execute();
                $result = $stmt->get_result();

                // Display search results
                if ($result->num_rows > 0) {
                    echo "<h2>Search Results:</h2>";
                    while ($row = $result->fetch_assoc()) {
                        $url = $row['url'];
                        echo "<div class='result-item'><strong>ID:</strong> " . $row['id'] . " <strong>Date:</strong> " . $row['date'] . " <strong>URL:</strong> <a href='$url' target='_blank'>$url</a> <strong>Contents:</strong> " . $row['contents'] . "</div>";
                    }
                } else {
                    echo "<div class='alert alert-warning'>No results found for '$search'</div>";
                }

                // Close the statement
                $stmt->close();
            }

            // Close the connection
            $conn->close();
            ?>
        </div>
    </div>
</div>

</body>
</html>