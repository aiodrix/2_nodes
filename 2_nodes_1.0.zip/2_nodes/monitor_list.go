package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

// readServers reads the server URLs from the servers.txt file.
func readServers(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var servers []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		servers = append(servers, scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return servers, nil
}

// listFiles lists all files in the specified directory.
func listFiles(dir string) ([]string, error) {
	var files []string
	err := filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			files = append(files, filepath.Base(path))
		}
		return nil
	})
	return files, err
}

// downloadFile downloads a file from the given URL and saves it to the specified path.
func downloadFile(url, filePath string) error {
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("failed to download file: %s, status code: %d", url, resp.StatusCode)
	}

	out, err := os.Create(filePath)
	if err != nil {
		return err
	}
	defer out.Close()

	_, err = io.Copy(out, resp.Body)
	return err
}

// computeFileHash computes the SHA-256 hash of the given file.
func computeFileHash(filePath string) (string, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer file.Close()

	hasher := sha256.New()
	if _, err := io.Copy(hasher, file); err != nil {
		return "", err
	}

	return hex.EncodeToString(hasher.Sum(nil)), nil
}

func main() {
	// Read servers from the servers.txt file
	servers, err := readServers("servers.txt")
	if err != nil {
		log.Fatalf("Failed to read servers: %v", err)
	}

	// List files in the 'files' directory
	files, err := listFiles("files")
	if err != nil {
		log.Fatalf("Failed to list files in directory: %v", err)
	}

	// Ensure the 'downloads' directory exists
	if err := os.MkdirAll("downloads", 0755); err != nil {
		log.Fatalf("Failed to create downloads directory: %v", err)
	}

	for _, filename := range files {
		expectedHash := strings.Split(filename, ".")[0]

		for _, server := range servers {
			fileURL := fmt.Sprintf("%s/files/%s", strings.TrimRight(server, "/"), filename)

			fmt.Printf("Checking file: %s\n", fileURL)

			// Define the path to save the downloaded file
			filePath := filepath.Join("downloads", filename)
			err := downloadFile(fileURL, filePath)
			if err != nil {
				log.Printf("Error downloading file from %s: %v\n", fileURL, err)
				continue
			}

			// Compute the hash of the downloaded file
			actualHash, err := computeFileHash(filePath)
			if err != nil {
				log.Printf("Error computing hash for file %s: %v\n", filename, err)
				continue
			}

			// Check if the hash matches the expected hash
			if actualHash == expectedHash {
				fmt.Printf("File %s downloaded successfully and hash matches.\n", filename)
			} else {
				fmt.Printf("File %s hash does not match. Expected: %s, Got: %s\n", filename, expectedHash, actualHash)
			}

			// Clean up the downloaded file
			if err := os.Remove(filePath); err != nil {
				log.Printf("Error removing file %s: %v\n", filePath, err)
			}
		}
	}
}
