<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL and Content Management</title>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            display: flex;
            flex-direction: row;
            margin: 50px;
        }
        .forms, .results {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-right: 20px;
        }
        .results {
            flex: 2;
            margin-left: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #007bff;
            color: #fff;
            padding: 10px;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            margin: -20px;
            margin-bottom: 20px;
        }
        .form-control {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-warning {
            background-color: #ff9800;
            color: white;
        }
        .alert-success {
            background-color: #4caf50;
            color: white;
        }
        .alert-danger {
            background-color: #f44336;
            color: white;
        }
        .result-item {
            margin-bottom: 10px;
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        .result-item a {
            color: #007bff;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="forms">
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Submit manually</h4>
            </div>
            <div class="card-body">
                <form action="server_list.php" method="post">
                    <input type="text" class="form-control" id="url" name="url" placeholder="URL" required>
                    <textarea class="form-control" id="contents" name="contents" rows="4" placeholder="About" required></textarea>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Search</h4>
            </div>
            <div class="card-body">
                <form action="server_list.php" method="get">
                    <input type="text" class="form-control" id="search" name="search" placeholder="Search by URL" required>
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
        </div>
    </div>
    <div class="results">
        <div class="search-results">
            <?php
            // Database connection details
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "aio2nodes";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Create table if it doesn't exist
            $sql = "CREATE TABLE IF NOT EXISTS servers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                url VARCHAR(255) UNIQUE,
                contents TEXT,
                ip_hash CHAR(32) UNIQUE
            )";

            if ($conn->query($sql) === FALSE) {
                echo "Error creating table: " . $conn->error;
            }

            // Get user IP address and hash it
            $user_ip = $_SERVER['REMOTE_ADDR'];
            $ip_hash = md5($user_ip);

            // Handle form submission for adding data
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['url']) && isset($_POST['contents'])) {
                $url = $_POST['url'];
                $contents = $_POST['contents'];

                // Check for duplicate URL or IP hash
                $stmt = $conn->prepare("SELECT COUNT(*) FROM servers WHERE url = ? OR ip_hash = ?");
                $stmt->bind_param("ss", $url, $ip_hash);
                $stmt->execute();
                $stmt->bind_result($count);
                $stmt->fetch();
                $stmt->close();

                if ($count > 0) {
                    echo "<div class='alert alert-warning'>Duplicate entry for URL or IP detected</div>";
                } else {
                    // Prepare and bind
                    $stmt = $conn->prepare("INSERT INTO servers (url, contents, ip_hash) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $url, $contents, $ip_hash);

                    // Execute the statement
                    if ($stmt->execute()) {
                        echo "<div class='alert alert-success'>New record created successfully</div>";
                    } else {
                        echo "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
                    }

                    // Close the statement
                    $stmt->close();
                }
            }

            // Handle search query
            if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
                $search = $_GET['search'];

                // Prepare and bind
                $stmt = $conn->prepare("SELECT id, date, url, contents FROM servers WHERE contents LIKE ?");
                $searchTerm = "%" . $search . "%";
                $stmt->bind_param("s", $searchTerm);

                // Execute the statement
                $stmt->execute();
                $result = $stmt->get_result();

                // Display search results
                if ($result->num_rows > 0) {
                    echo "<h2>Search Results:</h2>";
                    while ($row = $result->fetch_assoc()) {
                        $url = $row['url'];
                        echo "<div class='result-item'><strong>ID:</strong> " . $row['id'] . " <strong>Date:</strong> " . $row['date'] . " <strong>URL:</strong> <a href='$url' target='_blank'>$url</a> <strong>Contents:</strong> " . $row['contents'] . "</div>";
                    }
                } else {
                    echo "<div class='alert alert-warning'>No results found for '$search'</div>";
                }

                // Close the statement
                $stmt->close();
            }

            // Close the connection
            $conn->close();
            ?>
        </div>
    </div>
</div>
</body>
</html>