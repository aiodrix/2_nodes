package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

const filesDir = "./files"
const logFile = "log.txt"

func main() {
	http.HandleFunc("/", listFiles)
	http.HandleFunc("/download/", serveFiles)
	log.Println("Server started on :8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func listFiles(w http.ResponseWriter, r *http.Request) {
	files, err := ioutil.ReadDir(filesDir)
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		log.Printf("Error listing files: %v\n", err)
		return
	}

	html := "<h1>Files Available for Download</h1><ul>"
	for _, file := range files {
		if !file.IsDir() {
			fileName := file.Name()
			html += "<li><a href=\"/download/" + fileName + "\">" + fileName + "</a></li>"
		}
	}
	html += "</ul>"

	w.Write([]byte(html))
}

func serveFiles(w http.ResponseWriter, r *http.Request) {
	startTime := time.Now()
	fileName := strings.TrimPrefix(r.URL.Path, "/download/")
	filePath := filepath.Join(filesDir, fileName)

	// Check if file exists
	fileInfo, err := os.Stat(filePath)
	if err != nil {
		if os.IsNotExist(err) {
			http.NotFound(w, r)
			return
		}
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		log.Printf("Error accessing file: %v\n", err)
		return
	}

	// Open file
	fileContent, err := os.Open(filePath)
	if err != nil {
		http.Error(w, "Internal Server Error", http.StatusInternalServerError)
		log.Printf("Error opening file: %v\n", err)
		return
	}
	defer fileContent.Close()

	// Log download activity
	duration := time.Since(startTime)
	logEntry := fmt.Sprintf("[%s] %s - %s - %s - %s - %s - %d bytes - %s - %d ms - %s",
		time.Now().Format("2006-01-02 15:04:05"),
		r.RemoteAddr,
		fileName,
		r.Header.Get("User-Agent"),
		r.Header.Get("Referer"),
		r.Header.Get("Connection"),
		fileInfo.Size(),
		getStatusCodeText(w),
		duration.Milliseconds(),
	)
	appendToLogFile(logEntry)

	// Serve file
	http.ServeContent(w, r, fileInfo.Name(), fileInfo.ModTime(), fileContent)
}

func getStatusCodeText(w http.ResponseWriter) string {
	code := http.StatusOK
	if w, ok := w.(interface{ Status() int }); ok {
		code = w.Status()
	}
	return http.StatusText(code)
}

func appendToLogFile(entry string) {
	file, err := os.OpenFile(logFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Printf("Error opening log file: %v\n", err)
		return
	}
	defer file.Close()

	if _, err := file.WriteString(entry + "\n"); err != nil {
		log.Printf("Error writing to log file: %v\n", err)
	}
}