<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit and Search URL and Contents</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        h2 {
            text-align: center;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 8px;
            margin: 5px 0 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .results {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Submit URL and Contents</h2>
    <form action="server_list.php" method="post">
        <label for="url">URL:</label>
        <input type="text" id="url" name="url" required>

        <label for="contents">Contents:</label>
        <textarea id="contents" name="contents" rows="4" required></textarea>

        <input type="submit" value="Submit">
    </form>

    <h2>Search</h2>
    <form action="server_list.php" method="get">
        <label for="search">Search by URL:</label>
        <input type="text" id="search" name="search" required>

        <input type="submit" value="Search">
    </form>
</div>

</body>
</html>

<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aio2nodes";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS your_table_name (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    url VARCHAR(255),
    contents TEXT
)";

if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

// Handle form submission for adding data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['url']) && isset($_POST['contents'])) {
    $url = $_POST['url'];
    $contents = $_POST['contents'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO your_table_name (url, contents) VALUES (?, ?)");
    $stmt->bind_param("ss", $url, $contents);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Handle search query
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
    $search = $_GET['search'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT id, date, url, contents FROM your_table_name WHERE url LIKE ?");
    $searchTerm = "%" . $search . "%";
    $stmt->bind_param("s", $searchTerm);

    // Execute the statement
    $stmt->execute();
    $result = $stmt->get_result();

    // Display search results
    if ($result->num_rows > 0) {
        echo "<div class='results'><h2>Search Results:</h2><ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li><strong>ID:</strong> " . $row['id'] . " <strong>Date:</strong> " . $row['date'] . " <strong>URL:</strong> " . $row['url'] . " <strong>Contents:</strong> " . $row['contents'] . "</li>";
        }
        echo "</ul></div>";
    } else {
        echo "No results found for '$search'";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>