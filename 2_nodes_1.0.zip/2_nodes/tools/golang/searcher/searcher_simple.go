package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func handleSearch(w http.ResponseWriter, r *http.Request) {
	searchQuery := r.URL.Query().Get("search")
	if searchQuery == "" {
		http.Error(w, "No search query provided", http.StatusBadRequest)
		return
	}

	filesFound := make([]string, 0)

	err := filepath.Walk(".", func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() && (strings.Contains(info.Name(), searchQuery) || (info.Size() < 500000 && fileContainsText(path, searchQuery))) {
			filesFound = append(filesFound, path)
		}
		return nil
	})
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	if len(filesFound) == 0 {
		fmt.Fprintf(w, "No files found matching the search query '%s'\n", searchQuery)
		return
	}

	fmt.Fprintf(w, "<html><body>")
	fmt.Fprintf(w, "Files found matching the search query '%s':<br><br>", searchQuery)
	for _, file := range filesFound {
		fmt.Fprintf(w, "<a href=\"/view?file=%s\">%s</a><br>", file, file)
	}
	fmt.Fprintf(w, "</body></html>")
}

func fileContainsText(filename, text string) bool {
	content, err := ioutil.ReadFile(filename)
	if err != nil {
		return false
	}
	return strings.Contains(string(content), text)
}

func viewFile(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("file")
	if filePath == "" {
		http.Error(w, "No file specified", http.StatusBadRequest)
		return
	}

	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "text/plain")
	w.Write(content)
}

func main() {
	http.HandleFunc("/search", handleSearch)
	http.HandleFunc("/view", viewFile)
	fmt.Println("Server listening on port 8080...")
	http.ListenAndServe(":8080", nil)
}
