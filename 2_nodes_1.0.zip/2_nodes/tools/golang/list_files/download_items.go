package main

import (
    "crypto/tls"
    "fmt"
    "io"
    "net/http"
    "os" 
)

func main() {

    // Create a directory named "pics" if it doesn't exist
    err := os.Mkdir("pics", 0755)
    if err != nil && !os.IsExist(err) {
        fmt.Println("Error creating directory:", err)
        return
    }

    // Round transport to ignore SSL verification
    tr := &http.Transport{
        TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
    }

    // Create a http client with the custom transport
    client := &http.Client{Transport: tr}

    // Iterate through the range of images and download each
    for i := 10; i <= 50; i++ {
        imageURL := fmt.Sprintf("https://test.com/test-%d.jpg", i)
        filename := fmt.Sprintf("pics/test-%d.jpg", i)
        err := downloadImage(client, imageURL, filename)
        if err != nil {
            fmt.Println("Error downloading image:", err)
        } else {
            fmt.Println("Downloaded", filename)
        }
    }
}

func downloadImage(client *http.Client, url, filepath string) error {
    // Create or open the file
    file, err := os.Create(filepath)
    if err != nil {
        return err
    }
    defer file.Close()

    // Get the data from the URL
    response, err := client.Get(url)
    if err != nil {
        return err
    }
    defer response.Body.Close()

    // Write the data to the file
    _, err = io.Copy(file, response.Body)
    if err != nil {
        return err
    }

    return nil
}
