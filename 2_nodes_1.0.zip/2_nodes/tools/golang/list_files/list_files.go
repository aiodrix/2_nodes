package main

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"
)

func handler(w http.ResponseWriter, r *http.Request) {
	// Define root directory
	root := "./"

	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// Skip the root directory itself
		if path == root {
			return nil
		}

		// If it's a directory, create a link to navigate into the directory
		if info.IsDir() {
			fmt.Fprintf(w, "<a href=\"%s/\">%s</a><br>\n", path, info.Name())
		} else {
			// If it's a file, create a link to download the file
			fmt.Fprintf(w, "<a href=\"/download?file=%s\">%s</a><br>\n", path, info.Name())
		}
		return nil
	})

	if err != nil {
		fmt.Fprintf(w, "Error: %v", err)
		return
	}
}

func downloadHandler(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("file")

	// Open the file
	file, err := os.Open(filePath)
	if err != nil {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}
	defer file.Close()

	// Get file information
	fileInfo, err := file.Stat()
	if err != nil {
		http.Error(w, "Error reading file information", http.StatusInternalServerError)
		return
	}

	// Set the appropriate content type and send the file content to the browser
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=\"%s\"", filepath.Base(filePath)))
	http.ServeContent(w, r, filepath.Base(filePath), fileInfo.ModTime(), file)
}

func main() {
	http.HandleFunc("/", handler)
	http.HandleFunc("/download", downloadHandler)
	fmt.Println("Server listening on port 8080")
	http.ListenAndServe(":8080", nil)
}
