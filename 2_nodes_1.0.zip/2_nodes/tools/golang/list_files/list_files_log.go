package main

import (
	"fmt"
	"os"
	"path/filepath"
)

func listFiles(dir string) ([]string, error) {
	var files []string

	err := filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			// Get the relative path
			relPath, err := filepath.Rel(dir, path)
			if err != nil {
				return err
			}
			files = append(files, relPath)
		}
		return nil
	})

	if err != nil {
		return nil, err
	}

	return files, nil
}

func main() {
	// Get the current directory
	directory, err := os.Getwd()
	if err != nil {
		fmt.Printf("Error getting current directory: %s\n", err)
		return
	}

	files, err := listFiles(directory)
	if err != nil {
		fmt.Printf("Error listing files: %s\n", err)
		return
	}

	outputFile := "files.txt"
	file, err := os.Create(outputFile)
	if err != nil {
		fmt.Printf("Error creating file: %s\n", err)
		return
	}
	defer file.Close()

	for _, f := range files {
		_, err := fmt.Fprintf(file, "%s\n", f)
		if err != nil {
			fmt.Printf("Error writing to file: %s\n", err)
			return
		}
	}

	fmt.Printf("File list saved in %s\n", outputFile)
}
