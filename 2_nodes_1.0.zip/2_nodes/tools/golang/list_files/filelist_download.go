package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func downloadFile(url string, folder string) error {
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	// Extract filename from URL
	tokens := strings.Split(url, "/")
	filename := tokens[len(tokens)-1]

	// Check if the file already exists in the folder
	if _, err := os.Stat(filepath.Join(folder, filename)); err == nil {
		fmt.Printf("File %s already exists, skipping...\n", filename)
		return nil
	}

	// Create the file
	filePath := filepath.Join(folder, filename)
	file, err := os.Create(filePath)
	if err != nil {
		return err
	}
	defer file.Close()

	// Copy the content from HTTP response body to the file
	_, err = io.Copy(file, resp.Body)
	if err != nil {
		return err
	}

	fmt.Printf("Downloaded: %s\n", filename)
	return nil
}

func main() {
	var url string
	fmt.Print("Enter URL: ")
	fmt.Scanln(&url)

	// Create 'files' directory if it doesn't exist
	folder := "files"
	if _, err := os.Stat(folder); os.IsNotExist(err) {
		os.Mkdir(folder, os.ModePerm)
	}

	// Fetch page contents
	resp, err := http.Get(url)
	if err != nil {
		fmt.Println("Error:", err)
		return
	}
	defer resp.Body.Close()

	// Read page contents line by line
	var urls []string
	var buf [4096]byte
	for {
		n, err := resp.Body.Read(buf[:])
		if err != nil && err != io.EOF {
			fmt.Println("Error reading page:", err)
			return
		}
		if n == 0 {
			break
		}
		urls = append(urls, strings.Split(string(buf[:n]), "\n")...)
	}

	// Download files
	for _, link := range urls {
		link = strings.TrimSpace(link)
		if link != "" {
			err := downloadFile(link, folder)
			if err != nil {
				fmt.Println("Error downloading file:", err)
			}
		}
	}
}
