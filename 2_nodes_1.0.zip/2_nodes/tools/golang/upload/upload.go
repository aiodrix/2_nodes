package main

import (
	"crypto/sha256"
	"encoding/hex"
	"flag"
	"fmt"
	"html/template"
	"io"
	"net/http"
	"os"
	"path/filepath"
)

var (
	uploadFolder string
)

func main() {
	flag.StringVar(&uploadFolder, "upload-folder", "./uploads", "Folder to store uploaded files")
	flag.Parse()

	http.HandleFunc("/", homeHandler)
	http.HandleFunc("/upload", uploadHandler)

	fmt.Printf("Server is listening on :8080\n")
	http.ListenAndServe(":8080", nil)
}

func homeHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.New("index").Parse(`<html>
	<head><title>File Upload</title></head>
	<body>
		<h1>File Upload</h1>
		<form action="/upload" method="post" enctype="multipart/form-data">
			<label for="file">Select File:</label>
			<input type="file" name="file" id="file" required>
			<br>
			<label for="category">Select Category:</label>
			<input type="text" name="category" id="category" required>
			<br>
			<input type="submit" value="Upload">
		</form>
	</body>
	</html>`)

	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.Execute(w, nil)
}

func uploadHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	file, header, err := r.FormFile("file")
	if err != nil {
		http.Error(w, "Error retrieving the file", http.StatusBadRequest)
		return
	}
	defer file.Close()

	category := r.FormValue("category")

	// Create folder if not exists
	categoryFolder := filepath.Join(uploadFolder, category)
	if _, err := os.Stat(categoryFolder); os.IsNotExist(err) {
		err = os.MkdirAll(categoryFolder, 0755)
		if err != nil {
			http.Error(w, "Error creating category folder", http.StatusInternalServerError)
			return
		}
	}

	// Generate SHA256 hash as filename
	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		http.Error(w, "Error hashing the file", http.StatusInternalServerError)
		return
	}
	hashSum := hex.EncodeToString(hash.Sum(nil))

	// Extract the original file extension
	ext := filepath.Ext(header.Filename)

	// Combine hash and extension to create the final filename
	filename := hashSum + ext

	// Move the uploaded file to the category folder
	file.Seek(0, 0)
	destPath := filepath.Join(categoryFolder, filename)
	newFile, err := os.Create(destPath)
	if err != nil {
		http.Error(w, "Error creating the destination file", http.StatusInternalServerError)
		return
	}
	defer newFile.Close()

	if _, err := io.Copy(newFile, file); err != nil {
		http.Error(w, "Error copying the file to destination", http.StatusInternalServerError)
		return
	}

	fmt.Fprintf(w, "File uploaded successfully to category: %s, filename: %s", category, filename)
}