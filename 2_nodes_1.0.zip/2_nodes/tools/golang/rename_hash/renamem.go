package main

import (
    "crypto/sha256"
    "encoding/hex"
    "fmt"
    "io"
    "os"
    "path/filepath"
)

func main() {
    // Define the directory to traverse
    root := "./arts"

    // Walk through the directory and handle files
    err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
        if err != nil {
            return err
        }
        if info.IsDir() {
            return nil // Skip directories
        }

        // Compute the SHA256 hash of the file
        hash, err := hashFile(path)
        if err != nil {
            fmt.Printf("Error hashing file %s: %v\n", path, err)
            return nil // Continue walking
        }

        // Get the file extension
        ext := filepath.Ext(path)

        // Create the new file name with the hash and the original extension
        newFilename := filepath.Join(filepath.Dir(path), hash+ext)

        // Rename the file
        err = os.Rename(path, newFilename)
        if err != nil {
            fmt.Printf("Error renaming file %s to %s: %v\n", path, newFilename, err)
        } else {
            fmt.Printf("Renamed file %s to %s\n", path, newFilename)
        }

        return nil
    })

    if err != nil {
        fmt.Printf("Error walking the path %s: %v\n", root, err)
        return
    }
}

// hashFile calculates the SHA256 hash of a file
func hashFile(path string) (string, error) {
    file, err := os.Open(path)
    if err != nil {
        return "", err
    }
    defer file.Close()

    hasher := sha256.New()
    if _, err := io.Copy(hasher, file); err != nil {
        return "", err
    }

    hashInBytes := hasher.Sum(nil)
    return hex.EncodeToString(hashInBytes), nil
}
