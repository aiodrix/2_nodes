package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

func main() {
	// Define the folder containing the files
	folder := "files"

	// Open the folder
	dir, err := os.Open(folder)
	if err != nil {
		fmt.Println("Error opening folder:", err)
		return
	}
	defer dir.Close()

	// Read the files in the folder
	files, err := dir.Readdir(-1)
	if err != nil {
		fmt.Println("Error reading folder contents:", err)
		return
	}

	// Loop through each file
	for _, file := range files {
		if !file.IsDir() {
			// Calculate the SHA-256 hash of the file
			hash, err := calculateSHA256(filepath.Join(folder, file.Name()))
			if err != nil {
				fmt.Println("Error calculating hash for file", file.Name(), ":", err)
				continue
			}

			// Construct the new filename with the hash
			newFilename := hash + filepath.Ext(file.Name())

			// Rename the file
			err = os.Rename(filepath.Join(folder, file.Name()), filepath.Join(folder, newFilename))
			if err != nil {
				fmt.Println("Error renaming file", file.Name(), ":", err)
				continue
			}

			fmt.Println("Renamed", file.Name(), "to", newFilename)
		}
	}
}

// calculateSHA256 calculates the SHA-256 hash of a file
func calculateSHA256(filename string) (string, error) {
	// Open the file
	file, err := os.Open(filename)
	if err != nil {
		return "", err
	}
	defer file.Close()

	// Create a new SHA-256 hash
	hash := sha256.New()

	// Copy the file content to the hash function
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	// Convert the hash to a hex string
	hashString := hex.EncodeToString(hash.Sum(nil))

	return hashString, nil
}
