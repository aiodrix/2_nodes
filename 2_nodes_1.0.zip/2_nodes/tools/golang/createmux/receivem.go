package main

import (
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

func main() {
	http.HandleFunc("/", handler)
	http.ListenAndServe(":8080", nil)
}

func handler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseMultipartForm(10 << 20) // 10 MB maximum
		if err != nil {
			fmt.Fprintf(w, "Error parsing form: %v", err)
			return
		}

		thumbnailFile, handler, err := r.FormFile("thumbnail")
		if err != nil {
			fmt.Fprintf(w, "Error retrieving thumbnail file: %v", err)
			return
		}
		defer thumbnailFile.Close()

		title := r.FormValue("title")
		user := r.FormValue("user")
		url := r.FormValue("url")
		description := r.FormValue("description")
		category := r.FormValue("category")
		receivers := r.FormValue("receivers")

		// Check if the thumbnail file was uploaded successfully
		if err != nil {
			fmt.Fprintf(w, "Error uploading thumbnail file: %v", err)
			return
		}

		// Calculate SHA-256 hash of the file content
		thumbnailHash := hashFile(thumbnailFile)

		// Get the file extension of the uploaded thumbnail
		thumbnailExtension := filepath.Ext(handler.Filename)

		// Construct the filename using the hash and the original extension
		thumbnailFileName := thumbnailHash + thumbnailExtension

		// Define the target directory to save the file
		targetDirectory := "files/" + category + "/"
		thumbDirectory := "thumbs/"

		// Check if the target directory exists, and create it if not
		if _, err := os.Stat(targetDirectory); os.IsNotExist(err) {
			os.MkdirAll(targetDirectory, os.ModePerm)
		}
		// Check if the target directory exists, and create it if not
		if _, err := os.Stat(thumbDirectory); os.IsNotExist(err) {
			os.MkdirAll(thumbDirectory, os.ModePerm)
		}

		// Move the uploaded thumbnail to the target directory
		thumbnailPath := thumbDirectory + thumbnailFileName
		thumbnailFile.Seek(0, 0) // Reset the file pointer
		outFile, err := os.Create(thumbnailPath)
		if err != nil {
			fmt.Fprintf(w, "Error moving uploaded file: %v", err)
			return
		}
		defer outFile.Close()
		io.Copy(outFile, thumbnailFile)

		date := time.Now().Format("20060102")

		// Store other form data in a text file
		formData := fmt.Sprintf("<span class='thumbnail'><a href='../../%s%s' target='_blank'><img src='../../%s%s'></a></span><br>", thumbDirectory, thumbnailFileName, thumbDirectory, thumbnailFileName)
		formData += fmt.Sprintf("<span class='title'>%s</span> ", title)
		formData += fmt.Sprintf("<span class='user'>%s</span> ", user)
		formData += fmt.Sprintf("<span class='url'><a href='%s' target='_blank'>%s</a></span> ", url, url)
		formData += fmt.Sprintf("<span class='description'>%s</span> ", description)
		formData += fmt.Sprintf("<span class='category'>%s</span> ", category)
		formData += fmt.Sprintf("<span class='receivers'><a href='%s' target='_blank'>%s</a></span><hr><br>", receivers, receivers)
		formDataIndex := formData

		// Save the form data to a text file
		formDataFile := targetDirectory + date + ".html"
		formDataDefault := targetDirectory + "index.html"

		cssAndJsHeader := "<link rel='stylesheet' type='text/css' href='../../default.css'><script src='../../default.js'></script>"

		// Optional CSS and JS import files
		if _, err := os.Stat(formDataFile); os.IsNotExist(err) {
			formData = cssAndJsHeader + formData
		}

		outFile, err = os.OpenFile(formDataFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			fmt.Fprintf(w, "Error saving form data: %v", err)
			return
		}
		defer outFile.Close()
		outFile.WriteString(formData)

		indexPageSizeLimit := int64(10000)		

                indexSize, err := getFileSize(formDataDefault)
	        
                if err != nil {
		    fmt.Println("Error:", err)
		    indexSize = 0 // Set size to 0 if there's an error
	        }

		if indexSize < indexPageSizeLimit {
			if _, err := os.Stat(formDataDefault); os.IsNotExist(err) {
				formDataIndex = cssAndJsHeader + formDataIndex
			}

			outFile, err = os.OpenFile(formDataDefault, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
			if err != nil {
				fmt.Fprintf(w, "Error saving form data: %v", err)
				return
			}
			defer outFile.Close()
			outFile.WriteString(formDataIndex)
		}

		fmt.Fprint(w, "Content and image received successfully.")
	} else {
		fmt.Fprint(w, "Invalid request.")
	}
}

func hashFile(file io.Reader) string {
	hash := sha256.New()
	io.Copy(hash, file)
	return fmt.Sprintf("%x", hash.Sum(nil))
}

func getFileSize(filename string) (int64, error) {
	fileInfo, err := os.Stat(filename)
	if err != nil {
		return 0, err
	}
	return fileInfo.Size(), nil
}
