package main

import (
	"bytes"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
)

func main() {
	http.HandleFunc("/", handler)
	http.ListenAndServe(":8080", nil)
}

func handler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "POST" {
		err := r.ParseMultipartForm(10 << 20) // 10 MB maximum
		if err != nil {
			fmt.Fprintf(w, "Error parsing form: %v", err)
			return
		}

		thumbnailFile, _, err := r.FormFile("thumbnail")
		if err != nil {
			fmt.Fprintf(w, "Error retrieving thumbnail file: %v", err)
			return
		}
		defer thumbnailFile.Close()

		// Get other form values
		title := r.FormValue("title")
		user := r.FormValue("user")
		url := r.FormValue("url")
		description := r.FormValue("description")
		category := r.FormValue("category")
		receivers := r.Form["receivers"]

		// Create a buffer to store the form data
		var requestBody bytes.Buffer
		writer := multipart.NewWriter(&requestBody)

		// Add thumbnail file to the request
		thumbnailPart, err := writer.CreateFormFile("thumbnail", "thumbnail.jpg")
		if err != nil {
			fmt.Fprintf(w, "Error creating form file: %v", err)
			return
		}
		_, err = io.Copy(thumbnailPart, thumbnailFile)
		if err != nil {
			fmt.Fprintf(w, "Error copying file contents: %v", err)
			return
		}

		// Add other form fields to the request
		formFields := map[string]string{
			"title":       title,
			"user":        user,
			"url":         url,
			"description": description,
			"category":    category,
		}
		for key, value := range formFields {
			_ = writer.WriteField(key, value)
		}

		// Close the multipart writer
		err = writer.Close()
		if err != nil {
			fmt.Fprintf(w, "Error closing multipart writer: %v", err)
			return
		}

		// Iterate over receivers and send the request
		for _, receiver := range receivers {
			resp, err := http.Post(receiver, writer.FormDataContentType(), &requestBody)
			if err != nil {
				fmt.Fprintf(w, "Error sending request to %s: %v", receiver, err)
				return
			}
			defer resp.Body.Close()

			if resp.StatusCode != http.StatusOK {
				fmt.Fprintf(w, "Received non-OK status code from %s: %d", receiver, resp.StatusCode)
				return
			}
		}

		fmt.Fprint(w, "Content and image received successfully.")
	} else {
		fmt.Fprint(w, "Invalid request.")
	}
}
