package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"os"
)

func main() {
	// Handle GET requests
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodGet {
			// Get user IP address without the port
			userIP, _, err := net.SplitHostPort(r.RemoteAddr)
			if err != nil {
				fmt.Println("Error extracting IP address:", err)
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
				return
			}

			// Calculate SHA-256 hash of the user's IP address
			hash := sha256.Sum256([]byte(userIP))
			hashString := hex.EncodeToString(hash[:])

			// Folder name will be the hash value
			folderName := "data/" + hashString

			// Create the folder if it doesn't exist
			if _, err := os.Stat(folderName); os.IsNotExist(err) {
				os.MkdirAll(folderName, 0755)
			}

			// Get the data from the GET parameters
			data := r.URL.Query().Get("data")
			name := r.URL.Query().Get("name")

			// If 'name' variable is empty or not provided, use the hash value as the filename
			if name == "" {
				name = hashString
			}

			// Save data to a file inside the folder with the specified name
			fileName := folderName + "/" + name + ".txt"
			err = ioutil.WriteFile(fileName, []byte(data), 0644)
			if err != nil {
				fmt.Println("Error saving data:", err)
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
				return
			}

			fmt.Fprintf(w, "Data saved successfully in folder: %s with filename: %s", folderName, name)
		} else {
			// If request method is not GET, display an error message
			http.Error(w, "Error: Data should be sent via GET method.", http.StatusMethodNotAllowed)
		}
	})

	// Start the server on port 8080
	fmt.Println("Server listening on :8080")
	http.ListenAndServe(":8080", nil)
}
