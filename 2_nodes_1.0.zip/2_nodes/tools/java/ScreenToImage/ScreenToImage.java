import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ScreenToImage {
    private static final String IMAGE_FORMAT = "jpg";
    private static final String SAVE_DIRECTORY = "D:/";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMdd hh mm ss a");

    public void captureScreen() {
        try {
            Robot robot = new Robot();
            BufferedImage screenShot = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
            String fileName = DATE_FORMAT.format(Calendar.getInstance().getTime()) + "." + IMAGE_FORMAT;
            File outputFile = new File(SAVE_DIRECTORY, fileName);
            ImageIO.write(screenShot, IMAGE_FORMAT, outputFile);
            System.out.println("Screenshot saved: " + fileName);
        } catch (AWTException | IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        ScreenToImage screenToImage = new ScreenToImage();
        while (true) {
            screenToImage.captureScreen();
            Thread.sleep(10000); // Sleep for 10 seconds
        }
    }
}
