<?php
// Function to list all files in a directory and its subdirectories
function listFiles($dir) {
    $files = [];
    $dirIterator = new RecursiveDirectoryIterator($dir);
    $iterator = new RecursiveIteratorIterator($dirIterator, RecursiveIteratorIterator::SELF_FIRST);
    
    foreach ($iterator as $file) {
        // Exclude "." and ".." directories
        if ($file->isDir() && in_array($file->getBasename(), ['.', '..'])) {
            continue;
        }
        // Get relative path of the file
        $relativePath = substr($file->getPathname(), strlen($dir) + 1);
        $files[] = $relativePath;
    }
    
    return $files;
}

// Directory to list files from
$directory = '.'; // Change this to the directory you want to list files from

// Get list of files
$filesList = listFiles($directory);

// Save the list of files to a file
$fileHandle = fopen('files.txt', 'w');
foreach ($filesList as $file) {
    fwrite($fileHandle, $file . PHP_EOL);
}
fclose($fileHandle);

echo 'List of files saved to files.txt';
?>
