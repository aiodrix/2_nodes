<?php

// Function to download a file from a URL and save it to the 'files' folder
function downloadFile($url, $folder) {
    // Extract filename from URL
    $filename = basename($url);
    
    // Check if the file already exists in the folder
    if (file_exists($folder . '/' . $filename)) {
        echo "File $filename already exists, skipping...\n";
        return;
    }

    // Download file
    $fileContent = file_get_contents($url);
    if ($fileContent === false) {
        echo "Failed to download file: $url\n";
        return;
    }

    // Save file to 'files' folder
    file_put_contents($folder . '/' . $filename, $fileContent);
    echo "Downloaded: $filename\n";
}

// Get URL input from user
echo "Enter URL: ";
$url = trim($_GET['url']);

// Create 'files' directory if it doesn't exist
$folder = 'files';
if (!file_exists($folder)) {
    mkdir($folder, 0777, true);
}

// Fetch page contents
$pageContent = file_get_contents($url);
if ($pageContent === false) {
    echo "Failed to fetch page content from: $url\n";
    exit;
}

// Split page content by line breaks
$lines = explode("\n", $pageContent);

// Download files
foreach ($lines as $line) {
    $line = trim($line);
    if (!empty($line)) {
        downloadFile($line, $folder);
    }
}

?>
