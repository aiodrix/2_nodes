<?php
function handler() {
    // Define root directory
    $root = "./files/";

    // Iterate over files and directories in root directory
    $files = scandir($root);
    foreach ($files as $file) {
        // Skip current and parent directory entries
        if ($file === '.' || $file === '..') {
            continue;
        }

        $path = $root . $file;

        // If it's a directory, create a link to navigate into the directory
        if (is_dir($path)) {
            echo "<a href=\"$path/\">$file</a><br>\n";
        } else {
            // If it's a file, create a link to download the file
            echo "<a href='$path' target='_blank'>$file</a><br>\n";
        }
    }
}

function downloadHandler() {
    $filePath = $_GET['file'];

    // Check if the file exists
    if (!file_exists($filePath)) {
        http_response_code(404);
        echo "File not found";
        return;
    }

    // Set appropriate headers for download
    header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . filesize($filePath));

    // Read and output the file content
    readfile($filePath);
}

// Route requests to the appropriate handler
if (isset($_GET['file'])) {
    downloadHandler();
} else {
    handler();
}
?>
