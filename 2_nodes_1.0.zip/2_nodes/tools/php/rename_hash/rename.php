<?php
// Define the folder containing the files
$folder = "files";

// Open the folder
$dir = opendir($folder);
if (!$dir) {
    echo "Error opening folder: $folder";
    return;
}

// Read the files in the folder
while (($file = readdir($dir)) !== false) {
    if (!is_dir($folder . '/' . $file)) {
        // Calculate the SHA-256 hash of the file
        $hash = calculateSHA256("$folder/$file");
        if ($hash === false) {
            echo "Error calculating hash for file $file\n";
            continue;
        }

        // Construct the new filename with the hash
        $ext = pathinfo($file, PATHINFO_EXTENSION);
        $newFilename = $hash . '.' . $ext;

        // Rename the file
        if (!rename("$folder/$file", "$folder/$newFilename")) {
            echo "Error renaming file $file\n";
            continue;
        }

        echo "Renamed $file to $newFilename\n";
    }
}

// calculateSHA256 calculates the SHA-256 hash of a file
function calculateSHA256($filename) {
    // Check if file exists
    if (!file_exists($filename)) {
        return false;
    }

    // Calculate SHA-256 hash
    $hash = hash_file('sha256', $filename);
    if ($hash === false) {
        return false;
    }

    return $hash;
}
?>
