<?php
// Check if the file parameter exists in the request
if(isset($_FILES['file'])) {
    // Specify the directory where files will be saved
    $targetDir = "uploads/";
    
    // Create the target directory if it doesn't exist
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    // Get the uploaded file name
    $fileName = basename($_FILES['file']['name']);
    
    // Specify the path to store the uploaded file
    $targetFilePath = $targetDir . $fileName;
    
    // Move the uploaded file to the specified location
    if(move_uploaded_file($_FILES['file']['tmp_name'], $targetFilePath)){
        echo "The file ". $fileName . " has been uploaded successfully.";
    } else{
        echo "There was an error uploading your file.";
    }
} else {
    // If the file parameter is not found in the request
    echo "No file uploaded.";
}
?>
