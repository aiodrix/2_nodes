<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search Results</title>
</head>
<body>

<?php
$searchText = isset($_GET['search']) ? trim($_GET['search']) : ''; // Sanitize user input

if ($searchText) {
  echo "<h1>Search results for: $searchText</h1>";

  $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator('.'), RecursiveIteratorIterator::SELF_FIRST); // Optimized iteration order
  $foundFiles = []; // Store found files for efficiency

  foreach ($iterator as $file) {
    if ($file->isDir()) {
      continue; // Skip directories for file search
    }

    $filename = $file->getFilename();
    if (stripos($filename, $searchText) !== false) {
      $foundFiles[] = "<p><a href='" . $file->getPathname() . "' target='_blank'>File: $filename</a></p>";
    }
  }

  if ($foundFiles) {
    echo implode('', $foundFiles); // Efficient output of found files
  } else {
    echo "<p>No files found matching '$searchText'.</p>";
  }
} else {
  echo "<p>No search text provided. Use 'search' query parameter.</p>";
}
?>

</body>
</html>