
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aio2nodes";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Create table (if not exists)
$sql = "CREATE TABLE IF NOT EXISTS files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filehash VARCHAR(255) NOT NULL,
  filename VARCHAR(255) NOT NULL,
  fileextension VARCHAR(50) NOT NULL,
  date DATE NOT NULL,
  wallet VARCHAR(255) NOT NULL
)";

if (mysqli_query($conn, $sql)) {
  echo "Table files created successfully (or already exists)";
} else {
  echo "Error creating table: " . mysqli_error($conn);
}

// Handle search if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $searchTerm = mysqli_real_escape_string($conn, $_POST['search']);

  // Build search query
  $sql = "SELECT * FROM files WHERE filehash LIKE '%$searchTerm%' OR filename LIKE '%$searchTerm%' OR fileextension LIKE '%$searchTerm%' OR date LIKE '%$searchTerm%' OR wallet LIKE '%$searchTerm%'";

  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
    echo "<h2>Search Results</h2>";
    echo "<table>
      <tr>
        <th>ID</th>
        <th>File Hash</th>
        <th>Filename</th>
        <th>Extension</th>
        <th>Date</th>
        <th>Wallet</th>
      </tr>";
    while($row = mysqli_fetch_assoc($result)) {
      echo "<tr>
        <td>" . $row["id"] . "</td>
        <td>" . $row["filehash"] . "</td>
        <td>" . $row["filename"] . "</td>
        <td>" . $row["fileextension"] . "</td>
        <td>" . $row["date"] . "</td>
        <td>" . $row["wallet"] . "</td>
      </tr>";
    }
    echo "</table>";
  } else {
    echo "No results found!";
  }
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search Files</title>
</head>
<body>
  <h1>Search Files</h1>
  <form action="" method="post"> <label for="search">Search Term:</label>
    <input type="text" id="search" name="search" required>
    <br><br>
    <button type="submit">Search</button>
  </form>
</body>
</html>