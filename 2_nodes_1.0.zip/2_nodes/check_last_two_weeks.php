<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "aio2nodes";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Calculate the date two weeks ago from today and one week ago from today
$two_weeks_ago = date("Y-m-d", strtotime("-2 weeks"));
$one_week_ago = date("Y-m-d", strtotime("-1 week"));

// Query to sum income values for each hash value within the last two weeks for each entry
$sql = "SELECT hash, 
               SUM(CASE WHEN date >= '$two_weeks_ago' THEN income ELSE 0 END) AS total_income_last_two_weeks,
               SUM(CASE WHEN date >= '$one_week_ago' THEN income ELSE 0 END) AS total_income_last_week
        FROM income 
        GROUP BY hash
        ORDER BY total_income_last_week DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Hash: " . $row["hash"]. " - Total Income Last Two Weeks: " . $row["total_income_last_two_weeks"] . " - Total Income Last Week: " . $row["total_income_last_week"]. "<br>";
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();

?>