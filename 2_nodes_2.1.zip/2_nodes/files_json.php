<?php
// Define the directory
$dir = 'files';

// Initialize an array to hold the file information
$fileInfo = array();

// Check if the directory exists
if (is_dir($dir)) {
    // Open the directory
    if ($dh = opendir($dir)) {
        // Loop through the files in the directory
        while (($file = readdir($dh)) !== false) {
            // Skip the special '.' and '..' directories
            if ($file != "." && $file != "..") {
                // Get the file path
                $filePath = $dir . DIRECTORY_SEPARATOR . $file;
                // Check if it's a file and not a directory
                if (is_file($filePath)) {
                    // Get the file size
                    $fileSize = filesize($filePath);
                    // Add the file information to the array
                    $fileInfo[] = array(
                        'filename' => $file,
                        'filesize' => $fileSize
                    );
                }
            }
        }
        // Close the directory
        closedir($dh);
    } else {
        // Error opening directory
        echo json_encode(array('error' => 'Unable to open directory'));
        exit();
    }
} else {
    // Directory does not exist
    echo json_encode(array('error' => 'Directory does not exist'));
    exit();
}

// Output the file information as JSON
header('Content-Type: application/json');
echo json_encode($fileInfo);
?>
