package main

import (
	"encoding/json"
	"html/template"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
)

type Site struct {
	Site        string `json:"site"`
	Description string `json:"description"`
}

func main() {
	http.HandleFunc("/", searchHandler)
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func searchHandler(w http.ResponseWriter, r *http.Request) {
	var sites []Site

	data, err := ioutil.ReadFile("sites.json")
	if err != nil {
		http.Error(w, "Unable to read sites.json", http.StatusInternalServerError)
		log.Printf("Error reading sites.json: %v", err)
		return
	}

	err = json.Unmarshal(data, &sites)
	if err != nil {
		http.Error(w, "Error parsing JSON", http.StatusInternalServerError)
		log.Printf("Error parsing JSON: %v", err)
		return
	}

	query := r.URL.Query().Get("q")
	var results []Site

	if query != "" && strings.TrimSpace(query) != "" {
		for _, site := range sites {
			if strings.Contains(strings.ToLower(site.Description), strings.ToLower(query)) {
				results = append(results, site)
			}
		}
	}

	const tmplStr = `
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Site Search</title>
		<style>
			body {
				font-family: Arial, sans-serif;
				background-color: #f4f4f4;
				margin: 0;
				padding: 0;
				display: flex;
				justify-content: center;
				align-items: center;
				height: 100vh;
			}
			.container {
				background: #fff;
				padding: 20px;
				border-radius: 8px;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
				width: 100%;
				max-width: 600px;
			}
			h1 {
				margin-top: 0;
			}
			form {
				margin-bottom: 20px;
			}
			input[type="text"] {
				width: calc(100% - 100px);
				padding: 10px;
				margin-right: 10px;
				border: 1px solid #ccc;
				border-radius: 4px;
			}
			input[type="submit"] {
				padding: 10px 20px;
				border: none;
				background-color: #007BFF;
				color: white;
				border-radius: 4px;
				cursor: pointer;
			}
			input[type="submit"]:hover {
				background-color: #0056b3;
			}
			ul {
				list-style-type: none;
				padding: 0;
			}
			li {
				margin-bottom: 10px;
			}
			a {
				color: #007BFF;
				text-decoration: none;
			}
			a:hover {
				text-decoration: underline;
			}
		</style>
	</head>
	<body>
		<div class="container">
			<h1>Site Search</h1>
			<form method="get">
				<input type="text" name="q" placeholder="Search..." value="{{.Query}}">
				<input type="submit" value="Search">
			</form>
			<ul>
			{{range .Results}}
				<li><a href="{{.Site}}" target="_blank">{{.Description}}</a></li>
			{{else if .Query}}
				<li>No results found</li>
			{{end}}
			</ul>
		</div>
	</body>
	</html>
	`

	tmpl, err := template.New("results").Parse(tmplStr)
	if err != nil {
		http.Error(w, "Error creating template", http.StatusInternalServerError)
		log.Printf("Error creating template: %v", err)
		return
	}

	dataToTemplate := struct {
		Query   string
		Results []Site
	}{
		Query:   query,
		Results: results,
	}

	err = tmpl.Execute(w, dataToTemplate)
	if err != nil {
		http.Error(w, "Error rendering template", http.StatusInternalServerError)
		log.Printf("Error rendering template: %v", err)
	}
}
