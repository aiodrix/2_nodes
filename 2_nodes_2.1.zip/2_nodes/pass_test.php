<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'];
    if ($code === '1234') {
        echo 'valid';
    } else {
        echo 'invalid';
    }
}
?>