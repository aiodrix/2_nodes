<?php

function resizeImage($sourcePath, $destPath, $newHeight) {
    list($width, $height) = getimagesize($sourcePath);
    $ratio = $newHeight / $height;
    $newWidth = $width * $ratio;
    
    $image_p = imagecreatetruecolor($newWidth, $newHeight);
    $image = imagecreatefromjpeg($sourcePath);

    // Resizing the image
    imagecopyresampled($image_p, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

    // Save the resized image
    imagejpeg($image_p, $destPath, 100);

    imagedestroy($image);
    imagedestroy($image_p);

    return $destPath;
}

function createThumbnail($sourcePath, $destPath, $thumbWidth, $thumbHeight) {
    list($width, $height) = getimagesize($sourcePath);

    $src_x = ($width / 2) - ($thumbWidth / 2);
    $src_y = ($height / 2) - ($thumbHeight / 2);

    $image_p = imagecreatetruecolor($thumbWidth, $thumbHeight);
    $image = imagecreatefromjpeg($sourcePath);

    // Creating the thumbnail
    imagecopyresampled($image_p, $image, 0, 0, $src_x, $src_y, $thumbWidth, $thumbHeight, $thumbWidth, $thumbHeight);

    // Save the thumbnail
    imagejpeg($image_p, $destPath, 100);

    imagedestroy($image);
    imagedestroy($image_p);
}

$imgDir = 'imgs';
$resizedDir = 'resized';
$thumbnailDir = 'thumbnails';

// Create directories if not exist
if (!file_exists($resizedDir)) {
    mkdir($resizedDir, 0777, true);
}
if (!file_exists($thumbnailDir)) {
    mkdir($thumbnailDir, 0777, true);
}

$images = glob("$imgDir/*.{jpg,jpeg,png,gif}", GLOB_BRACE);

foreach ($images as $image) {
    $imageName = basename($image);
    $resizedPath = "$resizedDir/$imageName";
    $thumbnailPath = "$thumbnailDir/$imageName";

    // Resize the image
    $resizedImagePath = resizeImage($image, $resizedPath, 400);

    // Create a 400x400 thumbnail from the center
    createThumbnail($resizedImagePath, $thumbnailPath, 400, 400);

    echo "Processed: $imageName<br>";
}

?>
