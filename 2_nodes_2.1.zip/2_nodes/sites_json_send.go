package main

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"sync"
)

type Site struct {
	Site        string `json:"site"`
	Description string `json:"description"`
}

func main() {
	var sites []Site

	// Read the JSON file
	data, err := ioutil.ReadFile("sites.json")
	if err != nil {
		log.Fatalf("Unable to read sites.json: %v", err)
	}

	// Unmarshal JSON data into the sites slice
	err = json.Unmarshal(data, &sites)
	if err != nil {
		log.Fatalf("Error parsing JSON: %v", err)
	}

	// Create a WaitGroup to wait for all POST requests to complete
	var wg sync.WaitGroup

	for _, site := range sites {
		wg.Add(1)
		go func(s Site) {
			defer wg.Done()
			sendFileToURL(s.Site, data)
		}(site)
	}

	// Wait for all goroutines to complete
	wg.Wait()
	log.Println("All POST requests have been completed.")
}

func sendFileToURL(url string, data []byte) {
	// Create a new POST request with the JSON data as the body
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(data))
	if err != nil {
		log.Printf("Error sending POST request to %s: %v", url, err)
		return
	}
	defer resp.Body.Close()

	// Read the response body
	respBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Printf("Error reading response from %s: %v", url, err)
		return
	}

	// Log the response
	log.Printf("Response from %s: %s", url, string(respBody))
}
