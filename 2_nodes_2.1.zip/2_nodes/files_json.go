package main

import (
    "encoding/json"
    "io/ioutil"
    "log"
    "net/http"
    "os"
)

type FileInfo struct {
    Filename string `json:"filename"`
    Filesize int64  `json:"filesize"`
}

func main() {
    http.HandleFunc("/files", func(w http.ResponseWriter, r *http.Request) {
        dir := "files"

        // Initialize a slice to hold the file information
        var fileInfo []FileInfo

        // Check if the directory exists
        if _, err := os.Stat(dir); os.IsNotExist(err) {
            http.Error(w, `{"error": "Directory does not exist"}`, http.StatusInternalServerError)
            return
        }

        // Read the directory
        files, err := ioutil.ReadDir(dir)
        if err != nil {
            http.Error(w, `{"error": "Unable to open directory"}`, http.StatusInternalServerError)
            return
        }

        // Loop through the files in the directory
        for _, file := range files {
            if !file.IsDir() {
                     
                // Get the file size
                fileSize := file.Size()
                // Add the file information to the slice
                fileInfo = append(fileInfo, FileInfo{
                    Filename: file.Name(),
                    Filesize: fileSize,
                })
            }
        }

        // Output the file information as JSON
        w.Header().Set("Content-Type", "application/json")
        json.NewEncoder(w).Encode(fileInfo)
    })

    log.Println("Server started on :8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}