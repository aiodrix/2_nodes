<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "aio2nodes";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Calculate the date one week ago from today
$one_week_ago = date("Y-m-d", strtotime("-1 week"));

// Query to sum income values for each hash value within the last week
$sql = "SELECT hash, SUM(income) AS total_income 
        FROM income 
        WHERE date >= '$one_week_ago' 
        GROUP BY hash 
        ORDER BY total_income DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Hash: " . $row["hash"]. " - Total Income: " . $row["total_income"]. "<br>";
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();

?>