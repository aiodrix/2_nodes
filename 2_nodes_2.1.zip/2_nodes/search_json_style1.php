<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Files</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            padding: 20px;
            max-width: 800px;
            margin: 0 auto;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        #urls {
            width: 100%;
            height: 150px;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        #search {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        h2 {
            margin-top: 20px;
            color: #333;
        }

        h3 {
            margin-top: 15px;
            color: #666;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 5px;
        }

        a {
            color: #1e90ff;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .error {
            color: #f00;
            font-style: italic;
        }
    </style>
</head>
<body>
    <h1>Search Files from URLs</h1>
    <form method="POST">
        <label for="urls">Enter URLs (one per line):</label><br>
        <textarea id="urls" name="urls" rows="10" cols="50"></textarea><br>
        <label for="search">Search for:</label><br>
        <input type="text" id="search" name="search"><br><br>
        <input type="submit" value="Search">
    </form>

    <?php
    // PHP code remains the same
    ?>

</body>
</html>

    <?php

function removeAfterPenultimateSlash($url) {
    // Find the position of the last '/'
    $lastSlashPos = strrpos($url, '/');
    
    if ($lastSlashPos !== false) {
        // Find the position of the second-last '/'
        $secondLastSlashPos = strrpos(substr($url, 0, $lastSlashPos), '/');
        
        if ($secondLastSlashPos !== false) {
            // Return the substring up to (but not including) the second-last '/'
            return substr($url, 0, $secondLastSlashPos);
        } else {
            // Return the original URL if there is no second-last '/'
            return $url;
        }
    } else {
        // Return the original URL if no '/' is found
        return $url;
    }
}

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {


        $urls = explode("\n", trim($_POST['urls']));
        $searchTerm = trim($_POST['search']);

        $results = [];

        foreach ($urls as $url) {
            $url = trim($url);
            if (filter_var($url, FILTER_VALIDATE_URL)) {
                $json = @file_get_contents($url);
                if ($json !== FALSE) {
                    $files = json_decode($json, true);
                    if (json_last_error() === JSON_ERROR_NONE) {
                        foreach ($files as $file) {
                            if (strpos($file['filename'], $searchTerm) !== false) {
                                $file['url'] = rtrim($url, '/') . '/' . $file['filename'];
                                $results[$url][] = $file;
                            }
                        }
                    } else {
                        echo "<p>Invalid JSON from URL: $url</p>";
                    }
                } else {
                    echo "<p>Could not fetch data from URL: $url</p>";
                }
            } else {
                echo "<p>Invalid URL: $url</p>";
            }
        }

        if (!empty($results)) {
            echo "<h2>Search Results</h2>";
            foreach ($results as $url => $files) {
                echo "<h3>Results from: $url</h3>";
                echo "<ul>";
                foreach ($files as $file) {           

                    $fileURL = $file['url'];     
                    
                    $fileURLFormat = removeAfterPenultimateSlash($fileURL);          

                    $fileLink = $fileURLFormat . '/files/' . $file['filename'];
                                       
                    echo "<li><a href='$fileLink' target='_blank'>{$file['filename']}</a> ({$file['filesize']} bytes)</li>";
                }
                echo "</ul>";
            }
        } else {
            echo "<p>No matching files found.</p>";
        }
    }
    ?>
</body>
</html>