package main

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

type ServerInfo struct {
	URL       string
	FileCount int
	TotalSize int64
	Readme    string
}

type FileInfo struct {
	Name string `json:"name"`
	Size int64  `json:"size"`
}

type SearchResult struct {
	ServerURL  string
	FileName   string
	FileSize   int64
	MatchType  string // "filename" or "content"
	MatchValue string
}

var servers []string
var serverData []ServerInfo
var searchResults []SearchResult
var mu sync.Mutex

var tmpl = template.Must(template.New("index").Parse(`
<!DOCTYPE html>
<html>
<head>
	<title>P2P Server Info</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			background-color: #f4f4f4;
		}
		.container {
			width: 80%;
			margin: auto;
			overflow: hidden;
		}
		header {
			background: #50b3a2;
			color: #fff;
			padding-top: 30px;
			min-height: 70px;
			border-bottom: #e8491d 3px solid;
		}
		header a {
			color: #fff;
			text-decoration: none;
			text-transform: uppercase;
			font-size: 16px;
		}
		header ul {
			padding: 0;
			list-style: none;
		}
		header li {
			display: inline;
			padding: 0 20px 0 20px;
		}
		.table-container {
			margin: 40px 0;
		}
		table {
			width: 100%;
			margin: 20px 0;
			border-collapse: collapse;
		}
		table, th, td {
			border: 1px solid #ddd;
		}
		th, td {
			padding: 8px;
			text-align: left;
		}
		th {
			background-color: #f2f2f2;
		}
		.button {
			display: inline-block;
			padding: 10px 20px;
			font-size: 16px;
			cursor: pointer;
			text-align: center;
			text-decoration: none;
			outline: none;
			color: #fff;
			background-color: #4CAF50;
			border: none;
			border-radius: 15px;
			box-shadow: 0 4px #999;
		}
		.button:hover {background-color: #45a049}
		.button:active {
			background-color: #3e8e41;
			box-shadow: 0 5px #666;
			transform: translateY(4px);
		}
		footer {
			background: #333;
			color: #fff;
			text-align: center;
			padding: 10px 0;
			position: fixed;
			width: 100%;
			bottom: 0;
		}
		footer a {
			color: #50b3a2;
			text-decoration: none;
		}
	</style>
</head>
<body>
	<header>
		<div class="container">
			<h1>P2P Server Info</h1>
		</div>
	</header>
	<div class="container">
		<div class="table-container">
			<table>
				<tr>
					<th>Server URL</th>
					<th>File Count</th>
					<th>Total Size (bytes)</th>
					<th>Actions</th>
					<th>Readme</th>
				</tr>
				{{range .Servers}}
				<tr>
					<td>{{.URL}}</td>
					<td>{{.FileCount}}</td>
					<td>{{.TotalSize}}</td>
					<td><a href="/download?server={{.URL}}" class="button">Download All Files</a></td>
					<td><pre>{{.Readme}}</pre></td>
				</tr>
				{{end}}
			</table>
		</div>
		<div>
			<h2>Search Files</h2>
			<form action="/search" method="get">
				<input type="text" name="query" placeholder="Enter search term">
				<button type="submit" class="button">Search</button>
			</form>
			{{if .SearchResults}}
			<h3>Search Results</h3>
			<table>
				<tr>
					<th>Server URL</th>
					<th>File Name</th>
					<th>File Size</th>
					<th>Match Type</th>
					<th>Match Value</th>
				</tr>
				{{range .SearchResults}}
				<tr>
					<td>{{.ServerURL}}</td>
					<td><a href="/downloadfile?server={{.ServerURL}}&filename={{.FileName}}">{{.FileName}}</a></td>
					<td>{{.FileSize}}</td>
					<td>{{.MatchType}}</td>
					<td><pre>{{.MatchValue}}</pre></td>
				</tr>
				{{end}}
			</table>
			{{end}}
		</div>
	</div>
	<footer>
		<p>Contact: <a href="mailto:2nodesw@gmail.com">2nodesw@gmail.com</a> | <a href="/contact">Contact Form</a></p>
	</footer>
</body>
</html>
`))

func main() {
	var err error
	servers, err = readServers("p2p_servers.txt")
	if err != nil {
		fmt.Println("Error reading servers:", err)
		return
	}

	updateServerData()

	http.HandleFunc("/", indexHandler)
	http.HandleFunc("/download", downloadHandler)
	http.HandleFunc("/downloadfile", downloadFileHandler)
	http.HandleFunc("/contact", contactHandler)
	http.HandleFunc("/search", searchHandler)

	fmt.Println("Server is running at http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}

func readServers(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var servers []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		servers = append(servers, scanner.Text())
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return servers, nil
}

func getServerInfo(url string) (ServerInfo, error) {
	resp, err := http.Get(fmt.Sprintf("http://%s/files", url))
	if err != nil {
		return ServerInfo{}, err
	}
	defer resp.Body.Close()

	var files []FileInfo
	if err := json.NewDecoder(resp.Body).Decode(&files); err != nil {
		return ServerInfo{}, err
	}

	var totalSize int64
	for _, file := range files {
		totalSize += file.Size
	}

	readme, err := getReadme(url)
	if err != nil {
		readme = "No readme available"
	}

	return ServerInfo{
		URL:       url,
		FileCount: len(files),
		TotalSize: totalSize,
		Readme:    readme,
	}, nil
}

func getReadme(url string) (string, error) {
	resp, err := http.Get(fmt.Sprintf("http://%s/download/readme.txt", url))
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("readme.txt not found")
	}

	readme, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	return string(readme), nil
}

func updateServerData() {
	var wg sync.WaitGroup
	for _, url := range servers {
		wg.Add(1)
		go func(url string) {
			defer wg.Done()
			info, err := getServerInfo(url)
			if err != nil {
				fmt.Println("Error getting server info:", err)
				return
			}
			mu.Lock()
			serverData = append(serverData, info)
			mu.Unlock()
		}(url)
	}
	wg.Wait()
}

func indexHandler(w http.ResponseWriter, r *http.Request) {
	mu.Lock()
	defer mu.Unlock()
	data := struct {
		Servers       []ServerInfo
		SearchResults []SearchResult
	}{
		Servers:       serverData,
		SearchResults: searchResults,
	}
	tmpl.Execute(w, data)
}

func downloadHandler(w http.ResponseWriter, r *http.Request) {
	server := r.URL.Query().Get("server")
	if server == "" {
		http.Error(w, "Server not specified", http.StatusBadRequest)
		return
	}

	resp, err := http.Get(fmt.Sprintf("http://%s/files", server))
	if err != nil {
		http.Error(w, "Failed to get file list", http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()

	var files []FileInfo
	if err := json.NewDecoder(resp.Body).Decode(&files); err != nil {
		http.Error(w, "Failed to decode file list", http.StatusInternalServerError)
		return
	}

	hashedDir := createHashedDir(server)
	for _, file := range files {
		err := downloadFile(server, file.Name, hashedDir)
		if err != nil {
			http.Error(w, fmt.Sprintf("Failed to download file: %s", file.Name), http.StatusInternalServerError)
			return
		}
	}

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func createHashedDir(server string) string {
	hash := sha256.Sum256([]byte(server))
	hashedDir := filepath.Join("downloads", hex.EncodeToString(hash[:]))

	if _, err := os.Stat(hashedDir); os.IsNotExist(err) {
		os.MkdirAll(hashedDir, os.ModePerm)
	}

	return hashedDir
}

func downloadFile(server, filename, dir string) error {
	resp, err := http.Get(fmt.Sprintf("http://%s/download/%s", server, filename))
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	out, err := os.Create(filepath.Join(dir, filename))
	if err != nil {
		return err
	}
	defer out.Close()

	_, err = io.Copy(out, resp.Body)
	return err
}

func downloadFileHandler(w http.ResponseWriter, r *http.Request) {
	server := r.URL.Query().Get("server")
	filename := r.URL.Query().Get("filename")
	if server == "" || filename == "" {
		http.Error(w, "Server or filename not specified", http.StatusBadRequest)
		return
	}

	hashedDir := createHashedDir(server)
	err := downloadFile(server, filename, hashedDir)
	if err != nil {
		http.Error(w, fmt.Sprintf("Failed to download file: %s", filename), http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func searchHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query().Get("query")
	if query == "" {
		http.Error(w, "Query not specified", http.StatusBadRequest)
		return
	}

	var wg sync.WaitGroup
	searchResults = []SearchResult{} // Reset previous search results
	for _, url := range servers {
		wg.Add(1)
		go func(url string) {
			defer wg.Done()
			searchFiles(url, query)
		}(url)
	}
	wg.Wait()

	http.Redirect(w, r, "/", http.StatusSeeOther)
}

func searchFiles(server, query string) {
	resp, err := http.Get(fmt.Sprintf("http://%s/files", server))
	if err != nil {
		fmt.Println("Error getting file list from server:", err)
		return
	}
	defer resp.Body.Close()

	var files []FileInfo
	if err := json.NewDecoder(resp.Body).Decode(&files); err != nil {
		fmt.Println("Error decoding file list from server:", err)
		return
	}

	for _, file := range files {
		if strings.Contains(file.Name, query) {
			mu.Lock()
			searchResults = append(searchResults, SearchResult{
				ServerURL:  server,
				FileName:   file.Name,
				FileSize:   file.Size,
				MatchType:  "filename",
				MatchValue: query,
			})
			mu.Unlock()
		} else if strings.HasSuffix(file.Name, ".txt") || strings.HasSuffix(file.Name, ".html") {
			content, err := downloadFileContent(server, file.Name)
			if err == nil && strings.Contains(string(content), query) {
				mu.Lock()
				searchResults = append(searchResults, SearchResult{
					ServerURL:  server,
					FileName:   file.Name,
					FileSize:   file.Size,
					MatchType:  "content",
					MatchValue: query,
				})
				mu.Unlock()
			}
		}
	}
}

func downloadFileContent(server, filename string) ([]byte, error) {
	resp, err := http.Get(fmt.Sprintf("http://%s/download/%s", server, filename))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	content, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	return content, nil
}

func contactHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "<h1>Contact Page</h1><p>Please contact us at <a href='mailto:2nodesw@gmail.com'>2nodesw@gmail.com</a></p>")
}
