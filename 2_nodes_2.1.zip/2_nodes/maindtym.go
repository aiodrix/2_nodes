package main

import (
	"bufio"
        "bytes"
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
	"crypto/tls"
)

// In UTF-8 files sometimes is added he Byte Order Mark at beginning, that causes error in the first URL
func removeBOM(data []byte) []byte {
	return bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF})
}

func downloadFile(url string) (string, error) {
	// Create 'files' folder if it doesn't exist
	err := os.MkdirAll("files", os.ModePerm)
	if err != nil {
		return "", err
	}

	// Disable SSL certificate verification
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}

	// Create HTTP client with custom transport
	httpClient := &http.Client{Transport: tr}

	// Send HTTP GET request
	response, err := httpClient.Get(url)
	if err != nil {
		return "", err
	}
	defer response.Body.Close()

	// Extract filename from URL
	segments := strings.Split(url, "/")
	filename := segments[len(segments)-1]

	// Create a file to write the downloaded data
	outputFile, err := os.Create(filepath.Join("files", filename))
	if err != nil {
		return "", err
	}
	defer outputFile.Close()

	// Write the contents of the HTTP response to the file
	_, err = io.Copy(outputFile, response.Body)
	if err != nil {
		return "", err
	}

	return filename, nil
}

func calculateHash(filename string) (string, error) {
	// Open the file
	file, err := os.Open(filepath.Join("files", filename))
	if err != nil {
		return "", err
	}
	defer file.Close()

	// Calculate SHA-256 hash of the file
	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", hash.Sum(nil)), nil
}

func renameFile(oldFilename, newFilename string) error {
	// Rename the file
	err := os.Rename(filepath.Join("files", oldFilename), filepath.Join("files", newFilename))
	if err != nil {
		return err
	}
	return nil
}

func sendRequest(content, url, hash string) error {
	currentDate := time.Now().Format(time.RFC3339)
	requestURL := url + "?content=" + content + "&hash=" + hash + "&date=" + currentDate

	// Send HTTP GET request to test.com
	resp, err := http.Get(requestURL)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	return nil
}

func multipleRequests(url, hash string) {
    // Open the servers.txt file
    file, err := os.Open("servers.txt")
    if err != nil {
        fmt.Println("Error opening file:", err)
        return
    }
    defer file.Close()

    // Create a scanner to read the file line by line
    scanner := bufio.NewScanner(file)

    // Iterate over each line in the file
    for scanner.Scan() {
        // Get the server URL from the current line
        serverURL := scanner.Text()

        // Call the sendRequest method for the current server URL
        if err := sendRequest(serverURL, url, hash); err != nil {
            fmt.Printf("Error sending request to %s: %v\n", serverURL, err)
        } else {
            fmt.Printf("Request sent to %s successfully.\n", serverURL)
        }
    }

    // Check for any errors during scanning the file
    if err := scanner.Err(); err != nil {
        fmt.Println("Error scanning file:", err)
        return
    }

}

func removeDuplicates(inputFile, outputFile string) error {
    // Open the input file for reading
    inputFileHandle, err := os.Open(inputFile)
    if err != nil {
        return err
    }
    defer inputFileHandle.Close()

    // Create a map to store unique lines
    uniqueLines := make(map[string]bool)

    // Read each line from the input file and store it in the map
    scanner := bufio.NewScanner(inputFileHandle)
    for scanner.Scan() {
        line := scanner.Text()
        uniqueLines[line] = true
    }

    // Open the output file for writing
    outputFileHandle, err := os.Create(outputFile)
    if err != nil {
        return err
    }
    defer outputFileHandle.Close()

    // Write unique lines to the output file
    writer := bufio.NewWriter(outputFileHandle)
    for line := range uniqueLines {
        _, err := writer.WriteString(line + "\n")
        if err != nil {
            return err
        }
    }

    // Flush and close the writer
    err = writer.Flush()
    if err != nil {
        return err
    }

    return nil
}

func readAndCheckServers(filename string) error {
    // Open the file for reading
    file, err := os.OpenFile(filename, os.O_RDWR, 0644)
    if err != nil {
        return err
    }
    defer file.Close()

    scanner := bufio.NewScanner(file)

    for scanner.Scan() {
        url := scanner.Text()
        _, err := http.Get(url)
        if err != nil {
            // URL is unreachable, remove it from the file
            if err := removeLineFromFile(filename, url); err != nil {
                return err
            }
            fmt.Printf("%s is unreachable and has been removed from the file.\n", url)
        }
    }

    if err := scanner.Err(); err != nil {
        return err
    }

    return nil
}

func removeLineFromFile(filename string, text string) error {
    // Open the file for reading and writing
    file, err := os.OpenFile(filename, os.O_RDWR, 0644)
    if err != nil {
        return err
    }
    defer file.Close()

    scanner := bufio.NewScanner(file)
    writer := bufio.NewWriter(file)
    for scanner.Scan() {
        line := scanner.Text()
        if line != text {
            // Write the line back to the file if it doesn't match the text
            _, err := writer.WriteString(line + "\n")
            if err != nil {
                return err
            }
        }
    }
    // Truncate the file to the current position, removing the remaining contents
    err = file.Truncate(int64(writer.Buffered()))
    if err != nil {
        return err
    }
    // Flush the writer to ensure all buffered data is written to the file
    err = writer.Flush()
    if err != nil {
        return err
    }

    return nil
}

func main() {

        readAndCheckServers("servers.txt")

        inputFile := "files.txt"
        outputFile := "files.txt"

        err := removeDuplicates(inputFile, outputFile)
       if err != nil {
        fmt.Println("Error:", err)
        return
    }

	// Open files.txt
	fileList, err := os.Open("files.txt")
	if err != nil {
		fmt.Println("Error opening files.txt:", err)
		return
	}
	defer fileList.Close()

	// Remove BOM from files.txt content
	fileListStat, err := fileList.Stat()
	if err != nil {
		fmt.Println("Error getting file stats:", err)
		return
	}

	fileListData := make([]byte, fileListStat.Size())
	_, err = fileList.Read(fileListData)
	if err != nil {
		fmt.Println("Error reading files.txt:", err)
		return
	}

	fileListData = removeBOM(fileListData)

	// Create a reader for files.txt content
	fileListReader := bufio.NewReader(bytes.NewReader(fileListData))

	// Read each line (URL) from files.txt
	for {
		url, err := fileListReader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				break
			}
			fmt.Println("Error reading files.txt:", err)
			return
		}

		url = strings.TrimSpace(url)

		filename, err := downloadFile(url)
		if err != nil {
			fmt.Println("Error downloading file:", err)
			continue
		}
		fmt.Println("File downloaded and saved as:", filename)

		hash, err := calculateHash(filename)
		if err != nil {
			fmt.Println("Error calculating hash:", err)
			continue
		}
		fmt.Println("File hash:", hash)

		fileExt := filepath.Ext(filename)
		newFilename := hash + fileExt
		err = renameFile(filename, newFilename)
		if err != nil {
			fmt.Println("Error renaming file:", err)
			continue
		}
		fmt.Println("File renamed to:", newFilename)

		// Send request to test.com
		multipleRequests(url, hash)
		fmt.Println("Request sent successfully to test.com")
	}
}
