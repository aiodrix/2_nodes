package main

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"
)

func listFiles(dir string) ([]string, error) {
	var files []string

	err := filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			// Get the relative path
			relPath, err := filepath.Rel(dir, path)
			if err != nil {
				return err
			}
			files = append(files, relPath)
		}
		return nil
	})

	if err != nil {
		return nil, err
	}

	return files, nil
}

func handleListFiles(w http.ResponseWriter, r *http.Request) {
	// Get the current directory
	directory, err := os.Getwd()
	if err != nil {
		http.Error(w, fmt.Sprintf("Error getting current directory: %s", err), http.StatusInternalServerError)
		return
	}

	files, err := listFiles(directory)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error listing files: %s", err), http.StatusInternalServerError)
		return
	}

	outputFile := "files.txt"
	file, err := os.Create(outputFile)
	if err != nil {
		http.Error(w, fmt.Sprintf("Error creating file: %s", err), http.StatusInternalServerError)
		return
	}
	defer file.Close()

	for _, f := range files {
		_, err := fmt.Fprintf(file, "%s\n", f)
		if err != nil {
			http.Error(w, fmt.Sprintf("Error writing to file: %s", err), http.StatusInternalServerError)
			return
		}
	}

	fmt.Fprintf(w, "File list saved in %s\n", outputFile)
}

func main() {
	http.HandleFunc("/listfiles", handleListFiles)

	fmt.Println("Server started on port 8080")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		fmt.Printf("Failed to start server: %v", err)
	}
}
