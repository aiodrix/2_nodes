package main

import (
    "fmt"
    "io/ioutil"
    "net/http"
    "os"
    "path/filepath"
    "strings"
)

func handleSearch(w http.ResponseWriter, r *http.Request) {
    searchQuery := r.URL.Query().Get("search")
    if searchQuery == "" {
        http.Error(w, "No search query provided", http.StatusBadRequest)
        return
    }

    filesFound := make([]string, 0)

    err := filepath.Walk(".", func(path string, info os.FileInfo, err error) error {
        if err != nil {
            return err
        }
        if !info.IsDir() && (strings.Contains(info.Name(), searchQuery) || (info.Size() < 500000 && fileContainsText(path, searchQuery))) {
            filesFound = append(filesFound, path)
        }
        return nil
    })
    if err != nil {
        http.Error(w, err.Error(), http.StatusInternalServerError)
        return
    }

    if len(filesFound) == 0 {
        fmt.Fprintf(w, "No files found matching the search query '%s'\n", searchQuery)
        return
    }

    fmt.Fprintf(w, "Files found matching the search query '%s':\n", searchQuery)
    for i, file := range filesFound {
        fmt.Fprintf(w, "%d. %s\n", i+1, file)
        if i >= 99 { // Show a maximum of 100 results
            break
        }
    }
}

func fileContainsText(filename, text string) bool {
    content, err := ioutil.ReadFile(filename)
    if err != nil {
        return false
    }
    return strings.Contains(string(content), text)
}

func main() {
    http.HandleFunc("/search", handleSearch)
    fmt.Println("Server listening on port 8080...")
    http.ListenAndServe(":8080", nil)
}
