package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func handleSearch(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	searchQuery := r.FormValue("search")
	if searchQuery == "" {
		http.Error(w, "No search query provided", http.StatusBadRequest)
		return
	}

	filesFound := make([]string, 0)

	err := filepath.Walk(".", func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() && (strings.Contains(info.Name(), searchQuery) || (info.Size() < 500000 && fileContainsText(path, searchQuery))) {
			filesFound = append(filesFound, path)
		}
		return nil
	})
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	if len(filesFound) == 0 {
		fmt.Fprintf(w, "<html><head><style>%s</style></head><body>", searchFormStyle)
		fmt.Fprintf(w, "<div class=\"search-form-container\">")
		fmt.Fprintf(w, "<h2>No files found matching the search query '%s'</h2>", searchQuery)
		fmt.Fprintf(w, "</div>")
		fmt.Fprintf(w, "</body></html>")
		return
	}

	fmt.Fprintf(w, "<html><head><style>%s</style></head><body>", searchFormStyle)
	fmt.Fprintf(w, "<div class=\"search-form-container\">")
	fmt.Fprintf(w, "<h2>Files found matching the search query '%s':</h2>", searchQuery)
	fmt.Fprintf(w, "<div class=\"search-results\">")
	for _, file := range filesFound {
		fmt.Fprintf(w, "<a href=\"/view?file=%s\">%s</a><br>", file, file)
	}
	fmt.Fprintf(w, "</div>")
	fmt.Fprintf(w, "</div>")
	fmt.Fprintf(w, "</body></html>")
}

func viewFile(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("file")
	if filePath == "" {
		http.Error(w, "No file specified", http.StatusBadRequest)
		return
	}

	fileContent, err := ioutil.ReadFile(filePath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Set the appropriate content type based on the file extension
	contentType := http.DetectContentType(fileContent)
	w.Header().Set("Content-Type", contentType)

	// Set Content-Disposition header to indicate the file should be viewed in the browser
	w.Header().Set("Content-Disposition", "inline")

	// Write the file content to the response writer
	w.Write(fileContent)
}

func fileContainsText(filename, text string) bool {
	content, err := ioutil.ReadFile(filename)
	if err != nil {
		return false
	}
	return strings.Contains(string(content), text)
}

const searchFormStyle = `
    .search-form-container {
        text-align: center;
        margin-top: 50px;
    }

    .search-form-container h2 {
        font-size: 24px;
        margin-bottom: 20px;
    }

    .search-form-container input[type="text"] {
        width: 300px;
        padding: 10px;
        border: 2px solid #ccc;
        border-radius: 5px;
        font-size: 20px;
        margin-right: 10px;
    }

    .search-form-container input[type="submit"] {
        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 20px;
        cursor: pointer;
    }

    .search-results {
        text-align: left;
    }
`

func main() {
	http.HandleFunc("/search", handleSearch)
	http.HandleFunc("/view", viewFile)
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "<html><head><style>%s</style></head><body>", searchFormStyle)
		fmt.Fprintf(w, "<div class=\"search-form-container\">")
		fmt.Fprintf(w, "<h2>Search Files</h2>")
		fmt.Fprintf(w, "<form method=\"post\" action=\"/search\">")
		fmt.Fprintf(w, "<input type=\"text\" name=\"search\">")
		fmt.Fprintf(w, "<input type=\"submit\" value=\"Search\">")
		fmt.Fprintf(w, "</form>")
		fmt.Fprintf(w, "</div>")
		fmt.Fprintf(w, "</body></html>")
	})

	fmt.Println("Server listening on port 8080...")
	http.ListenAndServe(":8080", nil)
}
