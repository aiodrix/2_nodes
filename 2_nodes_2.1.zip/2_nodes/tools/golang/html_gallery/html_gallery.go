package main

import (
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
)

func main() {
	root := "./arts"

	// Walk through the directory and handle directories
	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if info.IsDir() {
			// Get the list of files in the directory
			files, err := ioutil.ReadDir(path)
			if err != nil {
				return err
			}

			// Create the HTML content with img tags
			htmlContent := "<html><body><div align='center'>"
			for _, file := range files {
				// Check if the file is an image
				if isImage(file.Name()) {
					// Construct the src attribute with only the file name
					src := file.Name()
					htmlContent += fmt.Sprintf("<a href=\"%s\"><img src=\"%s\" width=\"50%%\"></a><br><br>", src, src)
				}
			}
			htmlContent += "</div></body></html>"

			// Write HTML content to a file in the directory
			htmlFilePath := filepath.Join(path, "index.html")
			err = ioutil.WriteFile(htmlFilePath, []byte(htmlContent), 0644)
			if err != nil {
				return err
			}

			fmt.Printf("Created HTML file: %s\n", htmlFilePath)
		}
		return nil
	})

	if err != nil {
		fmt.Printf("Error walking the path %s: %v\n", root, err)
		return
	}
}

// isImage checks if a file is an image based on its extension
func isImage(filename string) bool {
	ext := filepath.Ext(filename)
	switch ext {
	case ".jpg", ".jpeg", ".png", ".gif":
		return true
	default:
		return false
	}
}
