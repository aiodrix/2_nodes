package main

import (
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"crypto/tls"
)

func downloadFile(url string) (string, error) {
	// Create 'files' folder if it doesn't exist
	err := os.MkdirAll("files", os.ModePerm)
	if err != nil {
		return "", err
	}

	// Disable SSL certificate verification
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}

	// Create HTTP client with custom transport
	httpClient := &http.Client{Transport: tr}

	// Send HTTP GET request
	response, err := httpClient.Get(url)
	if err != nil {
		return "", err
	}
	defer response.Body.Close()

	// Extract filename from URL
	segments := strings.Split(url, "/")
	filename := segments[len(segments)-1]

	// Create a file to write the downloaded data
	outputFile, err := os.Create(filepath.Join("files", filename))
	if err != nil {
		return "", err
	}
	defer outputFile.Close()

	// Write the contents of the HTTP response to the file
	_, err = io.Copy(outputFile, response.Body)
	if err != nil {
		return "", err
	}

	return filename, nil
}

func calculateHash(filename string) (string, error) {
	// Open the file
	file, err := os.Open(filepath.Join("files", filename))
	if err != nil {
		return "", err
	}
	defer file.Close()

	// Calculate SHA-256 hash of the file
	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", hash.Sum(nil)), nil
}

func renameFile(oldFilename, newFilename string) error {
	// Rename the file
	err := os.Rename(filepath.Join("files", oldFilename), filepath.Join("files", newFilename))
	if err != nil {
		return err
	}
	return nil
}

func main() {
	url := "https://sexyclube.uol.com.br/wp-content/uploads/2019/01/vivi-soares-06.jpg" // Replace with your desired URL
	filename, err := downloadFile(url)
	if err != nil {
		fmt.Println("Error downloading file:", err)
		return
	}
	fmt.Println("File downloaded and saved as:", filename)

	hash, err := calculateHash(filename)
	if err != nil {
		fmt.Println("Error calculating hash:", err)
		return
	}
	fmt.Println("File hash:", hash)

	fileExt := filepath.Ext(filename)
	newFilename := hash + fileExt
	err = renameFile(filename, newFilename)
	if err != nil {
		fmt.Println("Error renaming file:", err)
		return
	}
	fmt.Println("File renamed to:", newFilename)
}
