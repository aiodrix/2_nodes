package main

import (
	"bufio"
        "bytes"
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
	"crypto/tls"
)

func removeBOM(data []byte) []byte {
	return bytes.TrimPrefix(data, []byte{0xEF, 0xBB, 0xBF})
}

func downloadFile(url string) (string, error) {
	// Create 'files' folder if it doesn't exist
	err := os.MkdirAll("files", os.ModePerm)
	if err != nil {
		return "", err
	}

	// Disable SSL certificate verification
	tr := &http.Transport{
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
	}

	// Create HTTP client with custom transport
	httpClient := &http.Client{Transport: tr}

	// Send HTTP GET request
	response, err := httpClient.Get(url)
	if err != nil {
		return "", err
	}
	defer response.Body.Close()

	// Extract filename from URL
	segments := strings.Split(url, "/")
	filename := segments[len(segments)-1]

	// Create a file to write the downloaded data
	outputFile, err := os.Create(filepath.Join("files", filename))
	if err != nil {
		return "", err
	}
	defer outputFile.Close()

	// Write the contents of the HTTP response to the file
	_, err = io.Copy(outputFile, response.Body)
	if err != nil {
		return "", err
	}

	return filename, nil
}

func calculateHash(filename string) (string, error) {
	// Open the file
	file, err := os.Open(filepath.Join("files", filename))
	if err != nil {
		return "", err
	}
	defer file.Close()

	// Calculate SHA-256 hash of the file
	hash := sha256.New()
	if _, err := io.Copy(hash, file); err != nil {
		return "", err
	}

	return fmt.Sprintf("%x", hash.Sum(nil)), nil
}

func renameFile(oldFilename, newFilename string) error {
	// Rename the file
	err := os.Rename(filepath.Join("files", oldFilename), filepath.Join("files", newFilename))
	if err != nil {
		return err
	}
	return nil
}

func sendRequest(content, hash string) error {
	currentDate := time.Now().Format(time.RFC3339)
	requestURL := "http://test.com?content=" + content + "&hash=" + hash + "&date=" + currentDate

	// Send HTTP GET request to test.com
	resp, err := http.Get(requestURL)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	return nil
}

func main() {
	// Open files.txt
	fileList, err := os.Open("files.txt")
	if err != nil {
		fmt.Println("Error opening files.txt:", err)
		return
	}
	defer fileList.Close()

	// Remove BOM from files.txt content
	fileListStat, err := fileList.Stat()
	if err != nil {
		fmt.Println("Error getting file stats:", err)
		return
	}

	fileListData := make([]byte, fileListStat.Size())
	_, err = fileList.Read(fileListData)
	if err != nil {
		fmt.Println("Error reading files.txt:", err)
		return
	}

	fileListData = removeBOM(fileListData)

	// Create a reader for files.txt content
	fileListReader := bufio.NewReader(bytes.NewReader(fileListData))

	// Read each line (URL) from files.txt
	for {
		url, err := fileListReader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				break
			}
			fmt.Println("Error reading files.txt:", err)
			return
		}

		url = strings.TrimSpace(url)

		filename, err := downloadFile(url)
		if err != nil {
			fmt.Println("Error downloading file:", err)
			continue
		}
		fmt.Println("File downloaded and saved as:", filename)

		hash, err := calculateHash(filename)
		if err != nil {
			fmt.Println("Error calculating hash:", err)
			continue
		}
		fmt.Println("File hash:", hash)

		fileExt := filepath.Ext(filename)
		newFilename := hash + fileExt
		err = renameFile(filename, newFilename)
		if err != nil {
			fmt.Println("Error renaming file:", err)
			continue
		}
		fmt.Println("File renamed to:", newFilename)

		// Send request to test.com
		err = sendRequest(url, hash)
		if err != nil {
			fmt.Println("Error sending request to test.com:", err)
			continue
		}
		fmt.Println("Request sent successfully to test.com")
	}
}
