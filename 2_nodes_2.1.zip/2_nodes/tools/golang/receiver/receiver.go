package main

import (
    "fmt"
    "io/ioutil"
    "net/http"
    "os"
)

func uploadHandler(w http.ResponseWriter, r *http.Request) {
    // Check if the request contains a file
    file, handler, err := r.FormFile("file")
    if err != nil {
        http.Error(w, "No file uploaded", http.StatusBadRequest)
        return
    }
    defer file.Close()

    // Specify the directory where files will be saved
    targetDir := "uploads/"

    // Create the target directory if it doesn't exist
    if _, err := os.Stat(targetDir); os.IsNotExist(err) {
        os.MkdirAll(targetDir, 0777)
    }

    // Specify the path to store the uploaded file
    targetFilePath := targetDir + handler.Filename

    // Write the uploaded file to the specified location
    fileBytes, err := ioutil.ReadAll(file)
    if err != nil {
        http.Error(w, "Error reading file", http.StatusInternalServerError)
        return
    }
    err = ioutil.WriteFile(targetFilePath, fileBytes, 0644)
    if err != nil {
        http.Error(w, "Error saving file", http.StatusInternalServerError)
        return
    }

    // Respond with success message
    fmt.Fprintf(w, "The file %s has been uploaded successfully.", handler.Filename)
}

func main() {
    http.HandleFunc("/upload", uploadHandler)

    // Start server
    fmt.Println("Server listening on port 8080...")
    http.ListenAndServe(":8080", nil)
}
