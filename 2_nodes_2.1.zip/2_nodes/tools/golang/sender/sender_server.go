package main

import (
    "bytes"
    "fmt"
    "io"
    "mime/multipart"
    "net/http"
    "html/template"
)

// uploadHandler handles the file upload request
func uploadHandler(w http.ResponseWriter, r *http.Request) {
    // Parse the HTML form
    err := r.ParseMultipartForm(10 << 20) // Max size of 10MB
    if err != nil {
        http.Error(w, "Error parsing form", http.StatusInternalServerError)
        return
    }

    // Get the uploaded file from the form
    file, fileHeader, err := r.FormFile("file")
    if err != nil {
        http.Error(w, "No file uploaded", http.StatusBadRequest)
        return
    }
    defer file.Close()

    // Get the URLs from the textarea
    urls := r.FormValue("urls")
    if urls == "" {
        http.Error(w, "No URLs provided", http.StatusBadRequest)
        return
    }
    urlList := parseURLs(urls)

    // Upload the file to each URL
    err = uploadFile(file, fileHeader.Filename, urlList)
    if err != nil {
        http.Error(w, fmt.Sprintf("Error uploading file: %s", err), http.StatusInternalServerError)
        return
    }

    // Respond with success message
    w.Write([]byte("File uploaded successfully to the specified URLs"))
}

// parseURLs parses the newline-separated URLs from the textarea
func parseURLs(urls string) []string {
    urlList := make([]string, 0)
    lines := bytes.Split([]byte(urls), []byte("\n"))
    for _, line := range lines {
        if len(bytes.TrimSpace(line)) > 0 {
            urlList = append(urlList, string(line))
        }
    }
    return urlList
}

// uploadFile uploads the file to the specified URLs
func uploadFile(file io.Reader, filename string, urls []string) error {
    // Buffer to store the file data
    var requestBody bytes.Buffer
    writer := multipart.NewWriter(&requestBody)

    // Create form file field with the actual filename
    part, err := writer.CreateFormFile("file", filename)
    if err != nil {
        return err
    }

    // Copy file data to the part
    _, err = io.Copy(part, file)
    if err != nil {
        return err
    }

    // Close the multipart writer
    writer.Close()

    // Iterate over URLs and send POST requests
    for _, url := range urls {
        // Create HTTP request
        req, err := http.NewRequest("POST", url, &requestBody)
        if err != nil {
            return err
        }
        req.Header.Set("Content-Type", writer.FormDataContentType())

        // Send the request
        client := &http.Client{}
        resp, err := client.Do(req)
        if err != nil {
            return err
        }
        defer resp.Body.Close()

        // Print the response status
        fmt.Printf("Uploaded file '%s' to %s - Status: %s\n", filename, url, resp.Status)
    }

    return nil
}

// indexHandler serves the index.html file
func indexHandler(w http.ResponseWriter, r *http.Request) {
    tpl, err := template.ParseFiles("index.html")
    if err != nil {
        http.Error(w, "Error serving HTML", http.StatusInternalServerError)
        return
    }
    tpl.Execute(w, nil)
}

func main() {
    // Set up HTTP server
    http.HandleFunc("/", indexHandler)
    http.HandleFunc("/upload", uploadHandler)

    // Start server
    fmt.Println("Server listening on port 8080...")
    http.ListenAndServe(":8080", nil)
}
