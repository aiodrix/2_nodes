package main

import (
    "bytes"
    "fmt"
    "io"
    "mime/multipart"
    "net/http"
    "os"
)

func uploadFile(filepath string, url string) error {
    // Open the file
    file, err := os.Open(filepath)
    if err != nil {
        return err
    }
    defer file.Close()

    // Create a new buffer
    var requestBody bytes.Buffer
    writer := multipart.NewWriter(&requestBody)

    // Create a new form file field
    part, err := writer.CreateFormFile("file", filepath)
    if err != nil {
        return err
    }

    // Copy the file data to the part
    _, err = io.Copy(part, file)
    if err != nil {
        return err
    }

    // Close the multipart writer
    writer.Close()

    // Create the HTTP request
    req, err := http.NewRequest("POST", url, &requestBody)
    if err != nil {
        return err
    }

    // Set the content type header
    req.Header.Set("Content-Type", writer.FormDataContentType())

    // Send the request
    client := &http.Client{}
    resp, err := client.Do(req)
    if err != nil {
        return err
    }
    defer resp.Body.Close()

    // Print the response status
    fmt.Printf("Uploaded file %s to %s - Status: %s\n", filepath, url, resp.Status)

    return nil
}

func main() {
    filepath := "test.txt"
    hosts := []string{"http://localhost/aiodrix/projects/php/receiver/receiver.php", "http://host2.com/upload"}

    for _, host := range hosts {
        err := uploadFile(filepath, host)
        if err != nil {
            fmt.Printf("Error uploading file to %s: %s\n", host, err)
        }
    }
}
