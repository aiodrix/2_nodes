package main

import (
	"fmt"
	"math/rand"
	"time"
)

const (
	// Number of nodes in the network
	numNodes = 5
)

type Node struct {
	ID           int
	IsLeader     bool
	LastHeartbeat time.Time
}

func main() {
	rand.Seed(time.Now().UnixNano())

	nodes := make([]Node, numNodes)

	// Initialize nodes
	for i := 0; i < numNodes; i++ {
		nodes[i] = Node{
			ID:           i,
			IsLeader:     false,
			LastHeartbeat: time.Now(),
		}
	}

	// Start the leader election process
	go leaderElection(nodes)

	// Simulate nodes sending heartbeats
	for {
		time.Sleep(2 * time.Second)
		for i := range nodes {
			nodes[i].LastHeartbeat = time.Now()
		}
	}
}

func leaderElection(nodes []Node) {
	for {
		time.Sleep(1 * time.Second)

		// Elect leader
		leaderID := electLeader(nodes)
		fmt.Printf("Node %d is elected as the leader.\n", leaderID)

		// Set the leader
		for i := range nodes {
			nodes[i].IsLeader = (nodes[i].ID == leaderID)
		}
	}
}

func electLeader(nodes []Node) int {
	// Choose a random node as the leader
	return rand.Intn(numNodes)
}
