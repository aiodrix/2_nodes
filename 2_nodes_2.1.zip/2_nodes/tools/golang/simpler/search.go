package main

import (
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func handleRequest(w http.ResponseWriter, r *http.Request) {
	searchText := r.URL.Query().Get("search")

	if searchText != "" {
		fmt.Fprintf(w, "<h1>Search results for: %s</h1>", searchText)
		err := filepath.Walk(".", func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return fmt.Errorf("error accessing %s: %v", path, err)
			}

			if info.IsDir() {
				return nil // Skip directories for now
			}

			if match := matchesSearchText(info.Name(), searchText); match {
				fmt.Fprintf(w, "<p><a href='/file?path=%s'>%s</a></p>", path, path)
			}

			return nil
		})

		if err != nil {
			fmt.Fprintf(w, "<p>Error occurred while walking through directories: %s</p>", err)
		}
	} else {
		fmt.Fprint(w, "<p>No search text provided. Use 'search' query parameter.</p>")
	}
}

func handleFileRequest(w http.ResponseWriter, r *http.Request) {
	filePath := r.URL.Query().Get("path")
	if filePath != "" {
		http.ServeFile(w, r, filePath)
	} else {
		fmt.Fprint(w, "<p>No file path provided.</p>")
	}
}

func matchesSearchText(filename, searchText string) bool {
	return len(searchText) > 0 && strings.Contains(strings.ToLower(filename), strings.ToLower(searchText))
}

func main() {
	http.HandleFunc("/", handleRequest)
	http.HandleFunc("/file", handleFileRequest)
	port := 8080
	fmt.Printf("Server started on :%d\n", port)
	err := http.ListenAndServe(fmt.Sprintf(":%d", port), nil)
	if err != nil {
		fmt.Printf("Error starting server: %s\n", err)
	}
}