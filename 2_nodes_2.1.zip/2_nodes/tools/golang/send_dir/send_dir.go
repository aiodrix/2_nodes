package main

import (
    "bufio"
    "fmt"
    "io/ioutil"
    "net/http"
    "os"
    "path/filepath"
)

func main() {
    // Read the server address from the host.txt file
    hostFile := "host.txt"
    server, err := readHostFile(hostFile)
    if err != nil {
        fmt.Println("Error reading host file:", err)
        return
    }

    // Read files from the servers folder
    serversFolder := "servers"
    files, err := ioutil.ReadDir(serversFolder)
    if err != nil {
        fmt.Println("Error reading servers folder:", err)
        return
    }

    // Iterate over files in the servers folder
    for _, file := range files {
        // Read the URL from each file
        url, err := readURLFromFile(filepath.Join(serversFolder, file.Name()))
        if err != nil {
            fmt.Printf("Error reading URL from %s: %v\n", file.Name(), err)
            continue
        }

        // Access the URL
        resp, err := http.Get(url + "?data=" + server)
        if err != nil {
            fmt.Printf("Error accessing URL %s: %v\n", url, err)
            continue
        }
        defer resp.Body.Close()

        // Read the response body
        body, err := ioutil.ReadAll(resp.Body)
        if err != nil {
            fmt.Printf("Error reading response body from URL %s: %v\n", url, err)
            continue
        }

        // Print the response body
        fmt.Printf("Response from URL %s:\n%s\n", url, string(body))
    }
}

func readHostFile(filename string) (string, error) {
    content, err := ioutil.ReadFile(filename)
    if err != nil {
        return "", err
    }
    return string(content), nil
}

func readURLFromFile(filename string) (string, error) {
    file, err := os.Open(filename)
    if err != nil {
        return "", err
    }
    defer file.Close()

    scanner := bufio.NewScanner(file)
    if scanner.Scan() {
        return scanner.Text(), nil
    }
    if err := scanner.Err(); err != nil {
        return "", err
    }
    return "", nil
}
