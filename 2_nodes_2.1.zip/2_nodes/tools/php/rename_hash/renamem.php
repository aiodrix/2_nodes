<?php

// Define the directory to traverse
$root = './arts';

// Recursive function to traverse directories and rename files
function renameFiles($directory) {
    global $root;

    $files = scandir($directory);
    foreach ($files as $file) {
        if ($file != '.' && $file != '..') {
            $path = $directory . '/' . $file;
            if (is_dir($path)) {
                renameFiles($path); // Recursive call for directories
            } else {
                // Compute the SHA256 hash of the file
                $hash = hashFile($path);
                $ext = pathinfo($path, PATHINFO_EXTENSION);

                // Create the new file name with the hash and the original extension
                $newFilename = $directory . '/' . $hash . '.' . $ext;

                // Rename the file
                if (rename($path, $newFilename)) {
                    echo "Renamed file $path to $newFilename\n";
                } else {
                    echo "Error renaming file $path to $newFilename\n";
                }
            }
        }
    }
}

// Function to calculate the SHA256 hash of a file
function hashFile($path) {
    $hash = hash_file('sha256', $path);
    return $hash;
}

// Start the renaming process
renameFiles($root);

?>
