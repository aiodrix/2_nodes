<?php

// Check if data is sent via GET method and if 'name' variable is set
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    // Get user IP address
    $userIP = $_SERVER['REMOTE_ADDR'];

    // Calculate SHA-256 hash of the user's IP address
    $hash = hash('sha256', $userIP);

    // Folder name will be the hash value
    $folderName = "data/" . $hash;

    // Create the folder if it doesn't exist
    if (!is_dir($folderName)) {
        mkdir($folderName, 0755, true);
    }

    // Get the data from the GET parameters
    $data = $_GET['data'];
    $name = isset($_GET['name']) ? $_GET['name'] : '';

    if (empty($date)) {
        echo "";
    }

    // If 'name' variable is empty or not provided, use the hash value as the filename
    if (empty($name)) {
        $name = hash('sha256', $data);
    }

    // Save data to a file inside the folder with the specified name
    $fileName = $folderName . "/" . $name . ".txt";

    $file = fopen($fileName, "w");
    fwrite($file, $data);
    fclose($file); 

    echo "Data saved successfully in folder: " . $folderName . " with filename: " . $name;
} else {
    // If data is not sent via GET method, display an error message
    echo "Error: Data should be sent via GET method.";
}

?>
