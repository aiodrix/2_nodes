<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>File Upload</title>
</head>
<body>
    <h1>File Upload</h1>

    <?php
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $category = $_POST["category"];
        $uploadFolder = "./uploads";
        $categoryFolder = $uploadFolder . "/" . $category;

        if (!file_exists($categoryFolder)) {
            mkdir($categoryFolder, 0755, true);
        }

        $file = $_FILES["file"];
        $filename = $categoryFolder . "/" . hash_file("sha256", $file["tmp_name"]) . "." . pathinfo($file["name"], PATHINFO_EXTENSION);

        if (move_uploaded_file($file["tmp_name"], $filename)) {
            echo "File uploaded successfully to category: $category, filename: " . basename($filename);
        } else {
            echo "Error uploading file.";
        }
    }
    ?>

    <form action="" method="post" enctype="multipart/form-data">
        <label for="file">Select File:</label>
        <input type="file" name="file" id="file" required>
        <br>
        <label for="category">Select Category:</label>
        <input type="text" name="category" id="category" required>
        <br>
        <input type="submit" value="Upload">
    </form>
</body>
</html>