<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>
</head>
<body>
    <h1>File Upload</h1>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="file">Select file:</label><br>
        <input type="file" id="file" name="file"><br><br>
        <label for="urls">Enter URLs (one per line):</label><br>
        <textarea id="urls" name="urls" rows="5" cols="40"></textarea><br><br>
        <input type="submit" value="Upload">
    </form>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if the file was uploaded successfully
    if (!empty($_FILES['file']['tmp_name']) && is_uploaded_file($_FILES['file']['tmp_name'])) {
        // Get the uploaded file information
        $fileName = $_FILES['file']['name'];
        $fileTempName = $_FILES['file']['tmp_name'];

        // Read URLs from textarea
        $urls = explode("\n", $_POST['urls']);
        $urls = array_map('trim', $urls);

        // Upload file to each URL
        foreach ($urls as $url) {
            // Initialize cURL session
            $curl = curl_init();

            // Set cURL options
            curl_setopt_array($curl, [
                CURLOPT_URL => $url,
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => [
                    'file' => new CURLFile($fileTempName, null, $fileName)
                ],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => false
            ]);

            // Execute cURL request
            $response = curl_exec($curl);

            // Check for errors
            if ($response === false) {
                echo "Error uploading file to $url: " . curl_error($curl) . "<br>";
            } else {
                echo "File uploaded to $url successfully.<br>";
            }

            // Close cURL session
            curl_close($curl);
        }
    } else {
        echo "No file uploaded.<br>";
    }
}
?>
