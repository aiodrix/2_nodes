<?php

// Read the server address from the host.txt file
$hostFile = "host.txt";
$server = readHostFile($hostFile);
if ($server === false) {
    echo "Error reading host file: $hostFile\n";
    exit;
}

// Read files from the servers folder
$serversFolder = "servers";
$files = scandir($serversFolder);
if ($files === false) {
    echo "Error reading servers folder: $serversFolder\n";
    exit;
}

// Iterate over files in the servers folder
foreach ($files as $file) {
    if ($file == '.' || $file == '..') {
        continue; // Skip current and parent directory entries
    }

    // Read the URL from each file
    $url = readURLFromFile("$serversFolder/$file");
    if ($url === false) {
        echo "Error reading URL from $file\n";
        continue;
    }

    $fullUrl = $url . '?data=' . $server;

    // Access the URL
    $response = file_get_contents($fullUrl);
    if ($response === false) {
        echo "Error accessing URL $url\n";
        continue;
    }

    // Print the response
    echo "Response from URL $url:\n$response\n";
}

function readHostFile($filename) {
    $content = file_get_contents($filename);
    return $content !== false ? trim($content) : false;
}

function readURLFromFile($filename) {
    $url = file_get_contents($filename);
    return $url !== false ? trim($url) : false;
}
?>
