<?php

// Create a directory named "pics" if it doesn't exist
$picsDir = 'pics';
if (!file_exists($picsDir) && !is_dir($picsDir)) {
    mkdir($picsDir, 0755, true);
}

// Function to download an image
function downloadImage($url, $filepath) {
    $file = fopen($filepath, 'w');
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_FILE, $file);
    $response = curl_exec($ch);
    curl_close($ch);
    fclose($file);
    return $response;
}

// Iterate through the range of images and download each
for ($i = 10; $i <= 50; $i++) {
    $imageURL = sprintf("https://text.com/test-%d.jpg", $i);
    $filename = sprintf("%s/test-%d.jpg", $picsDir, $i);
    $result = downloadImage($imageURL, $filename);
    if ($result) {
        echo "Downloaded $filename\n";
    } else {
        echo "Error downloading image: $imageURL\n";
    }
}
?>
