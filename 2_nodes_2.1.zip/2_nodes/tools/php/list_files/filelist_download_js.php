<?php
// Check if URL is provided by the JavaScript
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['url'])) {
    // Function to download a file from a URL and save it to the 'files' folder
    function downloadFile($url, $folder) {
        // Extract filename from URL
        $filename = basename($url);
        
        // Check if the file already exists in the folder
        if (file_exists($folder . '/' . $filename)) {
            echo "File $filename already exists, skipping...\n";
            return;
        }

        // Download file
        $fileContent = file_get_contents($url);
        if ($fileContent === false) {
            echo "Failed to download file: $url\n";
            return;
        }

        // Save file to 'files' folder
        file_put_contents($folder . '/' . $filename, $fileContent);
        echo "Downloaded: $filename\n";
    }

    // Get URL input from JavaScript variable
    $url = trim($_POST['url']);

    // Create 'files' directory if it doesn't exist
    $folder = 'files';
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }

    // Fetch page contents
    $pageContent = file_get_contents($url);
    if ($pageContent === false) {
        echo "Failed to fetch page content from: $url\n";
        exit;
    }

    // Split page content by line breaks
    $lines = explode("\n", $pageContent);

    // Download files
    foreach ($lines as $line) {
        $line = trim($line);
        if (!empty($line)) {
            downloadFile($line, $folder);
        }
    }

    // Terminate PHP execution to prevent displaying the HTML form
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>URL Downloader</title>
</head>
<body>
<script>
// Get URL input from user
var url = prompt("Please enter the URL:");

// Send URL to PHP script
var xhr = new XMLHttpRequest();
xhr.open("POST", "", true); // Send to the same file
xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
xhr.onreadystatechange = function() {
  if (xhr.readyState === 4) {
    if (xhr.status === 200) {
      alert(xhr.responseText);
    } else {
      alert("Error: " + xhr.statusText);
    }
  }
};
xhr.send("url=" + encodeURIComponent(url));
</script>
</body>
</html>