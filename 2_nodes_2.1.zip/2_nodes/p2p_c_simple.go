package main

import (
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"io/ioutil"
)

const (
	clientDir   = "files"
	downloadDir = "downloads"
)

func uploadFiles(serverAddress string) error {
	files, err := ioutil.ReadDir(clientDir)
	if (err != nil) {
		return fmt.Errorf("failed to read client directory: %w", err)
	}

	for _, file := range files {
		if !file.IsDir() {
			filePath := filepath.Join(clientDir, file.Name())
			conn, err := net.Dial("tcp", serverAddress)
			if err != nil {
				return fmt.Errorf("failed to connect to server: %w", err)
			}
			defer conn.Close()

			fmt.Fprintln(conn, "UPLOAD")
			fmt.Fprintln(conn, file.Name())

			file, err := os.Open(filePath)
			if err != nil {
				return fmt.Errorf("failed to open file: %w", err)
			}
			defer file.Close()

			_, err = io.Copy(conn, file)
			if err != nil {
				return fmt.Errorf("failed to upload file: %w", err)
			}

			fmt.Printf("File %s uploaded successfully\n", file.Name())
		}
	}
	return nil
}

func downloadFiles(serverAddress string) error {
	conn, err := net.Dial("tcp", serverAddress)
	if err != nil {
		return fmt.Errorf("failed to connect to server: %w", err)
	}
	defer conn.Close()

	fmt.Fprintln(conn, "DOWNLOAD")

	if err := os.MkdirAll(downloadDir, 0755); err != nil {
		return fmt.Errorf("failed to create download directory: %w", err)
	}

	for {
		// Read file name length
		var fileNameLength int64
		err := binary.Read(conn, binary.LittleEndian, &fileNameLength)
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("failed to read file name length: %w", err)
		}

		// Read file name
		fileName := make([]byte, fileNameLength)
		_, err = io.ReadFull(conn, fileName)
		if err != nil {
			return fmt.Errorf("failed to read file name: %w", err)
		}

		// Read file size
		var fileSize int64
		err = binary.Read(conn, binary.LittleEndian, &fileSize)
		if err != nil {
			return fmt.Errorf("failed to read file size: %w", err)
		}

		filePath := filepath.Join(downloadDir, string(fileName))
		file, err := os.Create(filePath)
		if err != nil {
			return fmt.Errorf("failed to create file: %w", err)
		}
		defer file.Close()

		// Read file data
		_, err = io.CopyN(file, conn, fileSize)
		if err != nil {
			return fmt.Errorf("failed to download file: %w", err)
		}

		fmt.Printf("File %s downloaded successfully\n", string(fileName))
	}
	return nil
}

func main() {
	serverAddress := "localhost:8080"

	fmt.Println("Uploading files...")
	if err := uploadFiles(serverAddress); err != nil {
		fmt.Printf("Error uploading files: %v\n", err)
		return
	}

	fmt.Println("Downloading files...")
	if err := downloadFiles(serverAddress); err != nil {
		fmt.Printf("Error downloading files: %v\n", err)
		return
	}
}
