<!DOCTYPE html>
<html>
<head>
    <title>URL Formatter</title>
</head>
<body>
    <h2>URL Formatter</h2>
    <form method="post">
        <label for="urls">Enter URLs (one per line):</label><br><br>
        <textarea id="urls" name="urls" rows="10" cols="50"></textarea><br><br>
        <input type="submit" value="Format URLs">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $urls = $_POST["urls"];
        $urlArray = explode("\n", $urls);
        echo "<h3>Formatted URLs:</h3>";
        echo "<ul>";
        foreach ($urlArray as $url) {
            $url = trim($url);
            if (!empty($url)) {
                $parsedUrl = parse_url($url);
                $domain = $parsedUrl['scheme'] . '://' . $parsedUrl['host'];
                echo "<a href='$url' target='_blank'>$domain</a><br>";
            }
        }
        echo "</ul>";
    }
    ?>
</body>
</html>
