package main

import (
	"encoding/json"
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"
	"strings"
)

type FileInfo struct {
	Filename string `json:"filename"`
	Filesize int    `json:"filesize"`
}

type SearchResult struct {
	URL   string
	Files []FileInfo
}

var tmpl = template.Must(template.New("index").Parse(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Files</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        #urls {
            width: 100%;
            height: 150px;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        #search {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            padding: 12px 20px;
            font-size: 1rem;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .results {
            margin-top: 20px;
        }

        .results h2 {
            font-size: 1.8rem;
            margin-bottom: 10px;
            color: #333;
        }

        .results h3 {
            font-size: 1.5rem;
            margin-top: 15px;
            margin-bottom: 10px;
            color: #555;
        }

        .results ul {
            list-style-type: none;
            padding: 0;
            margin-bottom: 15px;
        }

        .results li {
            margin-bottom: 8px;
        }

        .results a {
            color: #1e90ff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .results a:hover {
            color: #0d6efd;
            text-decoration: underline;
        }

        .error {
            color: #dc3545;
            font-style: italic;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Search Files from URLs</h1>
        <form method="POST">
            <label for="urls">Enter URLs (one per line):</label>
            <textarea id="urls" name="urls" rows="5" placeholder="http://example.com/file.json&#10;http://another.com/data.json"></textarea><br><br>
            <label for="search">Search</label>
            <input type="text" id="search" name="search" placeholder="Enter file name or keyword"><br><br>
            <input type="submit" value="Search">
        </form>

        {{if .Error}}
        <p class="error">{{.Error}}</p>
        {{end}}

        {{if .Results}}
        <div class="results">
            <h2>Search Results</h2>
            {{range .Results}}
            <h3>Results from: {{.URL}}</h3>
            <ul>
                {{range .Files}}
                <li><a href="{{.Filename}}" target="_blank">{{.Filename}}</a> ({{.Filesize}} bytes)</li>
                {{end}}
            </ul>
            {{end}}
        </div>
        {{else if .Error}}
        <p class="error">No matching files found.</p>
        {{end}}
    </div>
</body>
</html>
`))

func main() {
	http.HandleFunc("/", indexHandler)
	http.ListenAndServe(":8080", nil)
}

func indexHandler(w http.ResponseWriter, r *http.Request) {
	var results []SearchResult
	var errorMsg string

	if r.Method == http.MethodPost {
		urls := strings.Split(r.FormValue("urls"), "\n")
		searchTerm := strings.TrimSpace(r.FormValue("search"))

		for _, url := range urls {
			url = strings.TrimSpace(url)
			if url == "" {
				continue
			}

			resp, err := http.Get(url)
			if err != nil {
				errorMsg = fmt.Sprintf("Could not fetch data from URL: %s", url)
				continue
			}
			defer resp.Body.Close()

			body, err := ioutil.ReadAll(resp.Body)
			if err != nil {
				errorMsg = fmt.Sprintf("Could not read data from URL: %s", url)
				continue
			}

			var files []FileInfo
			if err := json.Unmarshal(body, &files); err != nil {
				errorMsg = fmt.Sprintf("Invalid JSON from URL: %s", url)
				continue
			}

			var matchedFiles []FileInfo
			for _, file := range files {
				if strings.Contains(file.Filename, searchTerm) {
					filename := replacePenultimateSlash(strings.TrimRight(url, "/") + "/" + file.Filename)
					matchedFiles = append(matchedFiles, FileInfo{
						Filename: filename,
						Filesize: file.Filesize,
					})
				}
			}

			if len(matchedFiles) > 0 {
				results = append(results, SearchResult{
					URL:   url,
					Files: matchedFiles,
				})
			}
		}

		if len(results) == 0 {
			errorMsg = "No matching files found."
		}
	}

	data := struct {
		Results []SearchResult
		Error   string
	}{
		Results: results,
		Error:   errorMsg,
	}

	tmpl.Execute(w, data)
}

func replacePenultimateSlash(url string) string {
	slashIndex := strings.LastIndex(url, "/")
	if slashIndex == -1 {
		return url
	}

	secondLastSlashIndex := strings.LastIndex(url[:slashIndex], "/")
	if secondLastSlashIndex == -1 {
		return url
	}

	return url[:secondLastSlashIndex] + "/files" + url[slashIndex:]
}
