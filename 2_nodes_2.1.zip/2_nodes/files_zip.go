package main

import (
    "archive/zip"
    "crypto/sha256"
    "encoding/hex"
    "io"
    "io/ioutil"
    "log"
    "net/http"
    "os"
    "path/filepath"
)

func main() {
    http.HandleFunc("/download-zip", func(w http.ResponseWriter, r *http.Request) {
        dir := "files"

        // Create a temporary file to store the zip content
        tempFile, err := ioutil.TempFile("", "files-*.zip")
        if err != nil {
            http.Error(w, "Unable to create temporary file", http.StatusInternalServerError)
            return
        }
        defer os.Remove(tempFile.Name())

        // Create a new zip writer
        zipWriter := zip.NewWriter(tempFile)

        // Walk through the files in the directory
        err = filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
            if err != nil {
                return err
            }
            if !info.IsDir() {
                // Create a file in the zip archive
                file, err := zipWriter.Create(path[len(dir)+1:])
                if err != nil {
                    return err
                }

                // Open the source file
                srcFile, err := os.Open(path)
                if err != nil {
                    return err
                }
                defer srcFile.Close()

                // Copy the file content to the zip file
                _, err = io.Copy(file, srcFile)
                if err != nil {
                    return err
                }
            }
            return nil
        })

        if err != nil {
            http.Error(w, "Error creating zip file", http.StatusInternalServerError)
            return
        }

        // Close the zip writer
        zipWriter.Close()

        // Calculate the hash of the zip file
        tempFile.Seek(0, 0)
        hash := sha256.New()
        if _, err := io.Copy(hash, tempFile); err != nil {
            http.Error(w, "Error calculating hash", http.StatusInternalServerError)
            return
        }
        hashValue := hex.EncodeToString(hash.Sum(nil))

        // Set the appropriate headers
        w.Header().Set("Content-Disposition", "attachment; filename="+hashValue+".zip")
        w.Header().Set("Content-Type", "application/zip")

        // Serve the file content
        tempFile.Seek(0, 0)
        io.Copy(w, tempFile)
    })

    log.Println("Server started on :8080")
    log.Fatal(http.ListenAndServe(":8080", nil))
}