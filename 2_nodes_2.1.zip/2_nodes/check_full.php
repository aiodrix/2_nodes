<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Income Summary</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 800px;
    margin: 0 auto;
}

h1 {
    text-align: center;
}

.entry {
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    padding: 10px;
    margin-bottom: 10px;
}

.entry h2 {
    margin-top: 0;
}

.entry p {
    margin-top: 5px;
    margin-bottom: 5px;
}

.entry .total {
    font-weight: bold;
}

.footer {
    text-align: center;
    margin-top: 20px;
}
</style>
</head>
<body>

<div class="container">
    <h1>Income Summary</h1>

    <?php
    // Database connection parameters
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "aio2nodes";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Calculate the date two weeks ago from today and one week ago from today
    $two_weeks_ago = date("Y-m-d", strtotime("-2 weeks"));
    $one_week_ago = date("Y-m-d", strtotime("-1 week"));

    // Query to sum income values for each hash value within the last two weeks for each entry
    $sql = "SELECT hash, 
                   SUM(CASE WHEN date >= '$two_weeks_ago' THEN income ELSE 0 END) AS total_income_last_two_weeks,
                   SUM(CASE WHEN date >= '$one_week_ago' THEN income ELSE 0 END) AS total_income_last_week
            FROM income 
            GROUP BY hash
            ORDER BY total_income_last_week DESC";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            echo '<div class="entry">';
            echo '<h2>Hash: ' . $row["hash"] . '</h2>';
            echo '<p>Total Income Last Two Weeks: $' . $row["total_income_last_two_weeks"] . '</p>';
            echo '<p>Total Income Last Week: $' . $row["total_income_last_week"] . '</p>';
            echo '</div>';
        }
    } else {
        echo "0 results";
    }

    // Close connection
    $conn->close();
    ?>

    <div class="footer">
        Generated on: <?php echo date("Y-m-d H:i:s"); ?>
    </div>
</div>

</body>
</html>
