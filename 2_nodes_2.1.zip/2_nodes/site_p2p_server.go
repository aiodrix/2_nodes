package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
)

type FileInfo struct {
	Name string `json:"name"`
	Size int64  `json:"size"`
}

func main() {
	http.HandleFunc("/files", listFilesHandler)
	http.HandleFunc("/download/", downloadFileHandler)

	fmt.Println("P2P Server is running at http://localhost:8081")
	http.ListenAndServe(":8081", nil)
}

func listFilesHandler(w http.ResponseWriter, r *http.Request) {
	files, err := listFiles("files")
	if err != nil {
		http.Error(w, "Unable to list files", http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	if err := json.NewEncoder(w).Encode(files); err != nil {
		http.Error(w, "Unable to encode JSON", http.StatusInternalServerError)
	}
}

func listFiles(directory string) ([]FileInfo, error) {
	var files []FileInfo

	err := filepath.Walk(directory, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			files = append(files, FileInfo{Name: info.Name(), Size: info.Size()})
		}
		return nil
	})

	if err != nil {
		return nil, err
	}

	return files, nil
}

func downloadFileHandler(w http.ResponseWriter, r *http.Request) {
	filename := filepath.Base(r.URL.Path)
	filepath := filepath.Join("files", filename)

	file, err := os.Open(filepath)
	if err != nil {
		http.Error(w, "File not found", http.StatusNotFound)
		return
	}
	defer file.Close()

	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%s", filename))
	w.Header().Set("Content-Type", "application/octet-stream")
	if _, err := io.Copy(w, file); err != nil {
		http.Error(w, "Unable to send file", http.StatusInternalServerError)
	}
}
