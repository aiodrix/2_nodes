<?php

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "aio2nodes";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to create table
$sql = "CREATE TABLE income (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hash VARCHAR(255) NOT NULL,
    income DECIMAL(10, 2) NOT NULL,
    user VARCHAR(255) NOT NULL,
    date DATE NOT NULL
)";

// Execute SQL query
if ($conn->query($sql) === TRUE) {
    echo "Table created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

echo "<br>";

// Query to sum income values for each hash value
$sql = "SELECT hash, SUM(income) AS total_income FROM income GROUP BY hash ORDER BY total_income DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "Hash: " . $row["hash"]. " - Total Income: " . $row["total_income"]. "<br>";
    }
} else {
    echo "0 results";
}

$conn->close();
?>
