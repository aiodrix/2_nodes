<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Files</title>
    <style>
        /* Reset default browser styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 100%;
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        #urls {
            width: 100%;
            height: 150px;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }

        #search {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            padding: 12px 20px;
            font-size: 1rem;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .results {
            margin-top: 20px;
        }

        .results h2 {
            font-size: 1.8rem;
            margin-bottom: 10px;
            color: #333;
        }

        .results h3 {
            font-size: 1.5rem;
            margin-top: 15px;
            margin-bottom: 10px;
            color: #555;
        }

        .results ul {
            list-style-type: none;
            padding: 0;
            margin-bottom: 15px;
        }

        .results li {
            margin-bottom: 8px;
        }

        .results a {
            color: #1e90ff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .results a:hover {
            color: #0d6efd;
            text-decoration: underline;
        }

        .error {
            color: #dc3545;
            font-style: italic;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Search Files from URLs</h1>
        <form method="POST">
            <label for="urls">Enter URLs (one per line):</label>
            <textarea id="urls" name="urls" rows="5" placeholder="http://example.com/file.json&#10;http://another.com/data.json"></textarea><br><br>
            <label for="search">Search</label>
            <input type="text" id="search" name="search" placeholder="Enter file name or keyword"><br><br>
            <input type="submit" value="Search">
        </form>

        <?php
        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $urls = explode("\n", trim($_POST['urls']));
            $searchTerm = trim($_POST['search']);
            $results = [];

            foreach ($urls as $url) {
                $url = trim($url);
                if (filter_var($url, FILTER_VALIDATE_URL)) {
                    $json = @file_get_contents($url);
                    if ($json !== FALSE) {
                        $files = json_decode($json, true);
                        if (json_last_error() === JSON_ERROR_NONE) {
                            foreach ($files as $file) {
                                if (strpos($file['filename'], $searchTerm) !== false) {
                                    $fileURL = rtrim($url, '/') . '/' . $file['filename'];
                                    $results[$url][] = [
                                        'filename' => $file['filename'],
                                        'filesize' => $file['filesize'],
                                        'url' => $fileURL,
                                    ];
                                }
                            }
                        } else {
                            echo "<p class='error'>Invalid JSON from URL: $url</p>";
                        }
                    } else {
                        echo "<p class='error'>Could not fetch data from URL: $url</p>";
                    }
                } else {
                    echo "<p class='error'>Invalid URL: $url</p>";
                }
            }

            if (!empty($results)) {
                echo "<div class='results'>";
                echo "<h2>Search Results</h2>";
                foreach ($results as $url => $files) {
                    echo "<h3>Results from: $url</h3>";
                    echo "<ul>";
                    foreach ($files as $file) {
                        $fileLink = htmlspecialchars($file['url']); // Ensure URL is safe
                        echo "<li><a href='$fileLink' target='_blank'>{$file['filename']}</a> ({$file['filesize']} bytes)</li>";
                    }
                    echo "</ul>";
                }
                echo "</div>";
            } else {
                echo "<p class='error'>No matching files found.</p>";
            }
        }
        ?>

    </div>
</body>
</html>
