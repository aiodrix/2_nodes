<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>File Upload Form</title>
</head>
<body>
<h1>Upload File</h1>
<form action="receiver.php" method="post" enctype="multipart/form-data">
    <label for="file">Select a file to upload:</label><br>
    <input type="file" id="file" name="uploaded_file"><br><br>
    <label for="url">Enter the URL where the file will be sent:</label><br>
    <input type="text" id="url" name="upload_url" placeholder="http://example.com/receiver.php"><br><br>
    <input type="submit" value="Upload File">
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES["uploaded_file"]) && isset($_POST["upload_url"])) {
        $file = $_FILES["uploaded_file"];
        $fileName = $file["name"];
        $fileData = file_get_contents($file["tmp_name"]);

        $uploadUrl = $_POST["upload_url"];

        // Create a cURL handle
        $curl = curl_init();

        // Set the cURL options
        curl_setopt($curl, CURLOPT_URL, $uploadUrl);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, [
            'uploaded_file' => new CURLFile($file["tmp_name"], $file["type"], $fileName)
        ]);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        // Execute the cURL request
        $response = curl_exec($curl);

        // Check for errors
        if ($response === false) {
            echo "Error: " . curl_error($curl);
        } else {
            echo "File uploaded successfully to $uploadUrl";
        }

        // Close cURL session
        curl_close($curl);
    } else {
        echo "Please select a file and enter the URL where the file will be sent.";
    }
}
?>
</body>
</html>
