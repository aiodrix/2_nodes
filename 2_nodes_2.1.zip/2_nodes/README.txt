You are free to edit, use, and share this software as long as it is not for commercial purposes. To use it for commercial purposes, 
you must acquire a license. Any non-commercial edits must remain non-commercial.

For more information, read 'doc.html' or contact us.
We are not responsible for any losses or damages caused by the use of the software, nor for its use by third parties or others.

---------------------------------------------------------------------------------------------------------------------------------------

2_nodes - remote freelance services 

PHP programming / Golang / Web Developer / Virtual assistant /  IT / Translations / Text correction / Text creation with IA / Moderator /
Text to speech with AI / Image creation with AI / Project management / Administrative Assistant / Call Center / Manager / Content Creator /
Consulting / Software Developer / Customer Service / Consultant 
IT etc.

2nodesw@gmail.com