package main

import (
    "fmt"
    "io/ioutil"
    "log"
    "os"
    "path/filepath"
    "sort"
    "strconv"
)

func main() {
    dir := "order"

    // Read the directory
    files, err := ioutil.ReadDir(dir)
    if err != nil {
        log.Fatalf("Failed to read directory: %v", err)
    }

    // Extract the file names
    var fileNames []string
    for _, file := range files {
        if !file.IsDir() {
            fileNames = append(fileNames, file.Name())
        }
    }

    // Sort the file names
    sort.Strings(fileNames)

    // Rename each file in ascending order
    for i, fileName := range fileNames {
        ext := filepath.Ext(fileName)
        newName := strconv.Itoa(i+1) + ext
        oldPath := filepath.Join(dir, fileName)
        newPath := filepath.Join(dir, newName)

        err := os.Rename(oldPath, newPath)
        if err != nil {
            log.Fatalf("Failed to rename file %s to %s: %v", fileName, newName, err)
        }

        fmt.Printf("Renamed %s to %s\n", fileName, newName)
    }
}
