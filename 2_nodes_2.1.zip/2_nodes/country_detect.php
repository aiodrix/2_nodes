<?php
// List of Brazilian IP ranges (simplified for demonstration purposes)
$brazil_ip_ranges = [
    ['start' => ip2long('177.0.0.0'), 'end' => ip2long('177.255.255.255')],
    ['start' => ip2long('179.0.0.0'), 'end' => ip2long('179.255.255.255')],
    ['start' => ip2long('200.0.0.0'), 'end' => ip2long('200.255.255.255')],
    // Add more ranges as needed
];

// Function to get the user's IP address
function getUserIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

// Function to check if IP is within the given range
function isIPInRange($ip, $range) {
    $long_ip = ip2long($ip);
    return $long_ip >= $range['start'] && $long_ip <= $range['end'];
}

// Get the user's IP address
$user_ip = getUserIP();

// Check if the user's IP is from Brazil
$is_from_brazil = false;
foreach ($brazil_ip_ranges as $range) {
    if (isIPInRange($user_ip, $range)) {
        $is_from_brazil = true;
        break;
    }
}

// Redirect if the IP is from Brazil
if ($is_from_brazil) {
    header("Location: index_pt.html");
    exit();
}

// If not from Brazil, you can handle it here
// For example, redirect to an English index page or do nothing
// header("Location: index_en.html");
?>
