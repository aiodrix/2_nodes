<?php

$dir = 'order';

// Open the directory
if (!is_dir($dir)) {
    die("Directory $dir does not exist");
}

$files = array_diff(scandir($dir), array('.', '..'));

// Filter out directories and sort files
$fileNames = [];
foreach ($files as $file) {
    if (is_file("$dir/$file")) {
        $fileNames[] = $file;
    }
}

sort($fileNames);

// Rename files in ascending order
foreach ($fileNames as $index => $fileName) {
    $extension = pathinfo($fileName, PATHINFO_EXTENSION);
    $newName = ($index + 1) . ($extension ? ".$extension" : '');
    $oldPath = "$dir/$fileName";
    $newPath = "$dir/$newName";

    if (!rename($oldPath, $newPath)) {
        die("Failed to rename $fileName to $newName");
    }

    echo "Renamed $fileName to $newName\n";
}

?>
