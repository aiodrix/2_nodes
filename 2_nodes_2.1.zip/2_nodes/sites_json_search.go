package main

import (
	"encoding/json"
	"html/template"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
)

type Site struct {
	Site        string `json:"site"`
	Description string `json:"description"`
}

func main() {
	http.HandleFunc("/", searchHandler)
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func searchHandler(w http.ResponseWriter, r *http.Request) {
	var sites []Site

	data, err := ioutil.ReadFile("sites.json")
	if err != nil {
		http.Error(w, "Unable to read sites.json", http.StatusInternalServerError)
		return
	}

	err = json.Unmarshal(data, &sites)
	if err != nil {
		http.Error(w, "Error parsing JSON", http.StatusInternalServerError)
		return
	}

	query := r.URL.Query().Get("q")
	var results []Site

	if query != "" {
		for _, site := range sites {
			if strings.Contains(strings.ToLower(site.Description), strings.ToLower(query)) {
				results = append(results, site)
			}
		}
	} else {
		results = sites
	}

	tmpl, err := template.New("results").Parse(`
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Site Search</title>
	</head>
	<body>
		<h1>Site Search</h1>
		<form method="get">
			<input type="text" name="q" placeholder="Search..." value="{{.Query}}">
			<input type="submit" value="Search">
		</form>
		<ul>
		{{range .Results}}
			<li><a href="{{.Site}}" target="_blank">{{.Description}}</a></li>
		{{else}}
			<li>No results found</li>
		{{end}}
		</ul>
	</body>
	</html>
	`)

	if err != nil {
		http.Error(w, "Error creating template", http.StatusInternalServerError)
		return
	}

	dataToTemplate := struct {
		Query   string
		Results []Site
	}{
		Query:   query,
		Results: results,
	}

	err = tmpl.Execute(w, dataToTemplate)
	if err != nil {
		http.Error(w, "Error rendering template", http.StatusInternalServerError)
	}
}