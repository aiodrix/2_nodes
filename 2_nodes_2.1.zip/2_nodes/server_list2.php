<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL and Content Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #007bff;
            color: #fff;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004d99;
        }
        .search-results {
            margin-top: 30px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Submit manually</h4>
                </div>
                <div class="card-body">
                    <form action="server_list.php" method="post">
                        <div class="mb-3">
                            <label for="url" class="form-label">URL</label>
                            <input type="text" class="form-control" id="url" name="url" required>
                        </div>
                        <div class="mb-3">
                            <label for="contents" class="form-label">About</label>
                            <textarea class="form-control" id="contents" name="contents" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Search</h4>
                </div>
                <div class="card-body">
                    <form action="server_list.php" method="get">
                        <div class="mb-3">
                            <input type="text" class="form-control" id="search" name="search" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="search-results">
<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aio2nodes";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS servers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    url VARCHAR(255) UNIQUE,
    contents TEXT,
    ip_hash CHAR(32) UNIQUE
)";

if ($conn->query($sql) === FALSE) {
    echo "Error creating table: " . $conn->error;
}

// Get user IP address and hash it
$user_ip = $_SERVER['REMOTE_ADDR'];
$ip_hash = md5($user_ip);

// Handle form submission for adding data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['url']) && isset($_POST['contents'])) {
    $url = $_POST['url'];
    $contents = $_POST['contents'];

    // Check for duplicate URL or IP hash
    $stmt = $conn->prepare("SELECT COUNT(*) FROM servers WHERE url = ? OR ip_hash = ?");
    $stmt->bind_param("ss", $url, $ip_hash);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        echo "<div class='search-results'><div class='alert alert-warning'>Duplicate entry for URL or IP detected</div></div>";
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO servers (url, contents, ip_hash) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $url, $contents, $ip_hash);

        // Execute the statement
        if ($stmt->execute()) {
            echo "<div class='search-results'><div class='alert alert-success'>New record created successfully</div></div>";
        } else {
            echo "<div class='search-results'><div class='alert alert-danger'>Error: " . $stmt->error . "</div></div>";
        }

        // Close the statement
        $stmt->close();
    }
}

// Handle search query
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['search'])) {
    $search = $_GET['search'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT id, date, url, contents FROM servers WHERE contents LIKE ?");
    $searchTerm = "%" . $search . "%";
    $stmt->bind_param("s", $searchTerm);

    // Execute the statement
    $stmt->execute();
    $result = $stmt->get_result();

    // Display search results
    if ($result->num_rows > 0) {
        echo "<div class='search-results'><h2>Search Results:</h2>";
        while ($row = $result->fetch_assoc()) {
            $url = $row['url'];
            echo "<div class='result-item'><strong>ID:</strong> " . $row['id'] . " <strong>Date:</strong> " . $row['date'] . " <strong>URL:</strong> <a href='$url' target='_blank'>$url</a>" . "<strong>Contents:</strong> " . $row['contents'] . "</div>";
        }
        echo "</div>";
    } else {
        echo "<div class='search-results'><div class='alert alert-warning'>No results found for '$search'</div></div>";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>

    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>