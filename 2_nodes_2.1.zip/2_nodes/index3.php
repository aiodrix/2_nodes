<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aio2nodes";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Create table (if not exists)
$sql = "CREATE TABLE IF NOT EXISTS files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filehash VARCHAR(255) NOT NULL,
  filename VARCHAR(255) NOT NULL,
  filemime VARCHAR(255) NOT NULL,
  filesize VARCHAR(255) NOT NULL,
  fileextension VARCHAR(50) NOT NULL,
  date DATE NOT NULL,
  wallet VARCHAR(255) NOT NULL,
  url VARCHAR(255) DEFAULT NULL
)";

if (mysqli_query($conn, $sql)) {
  //echo "Table files created successfully (or already exists)";
} else {
  echo "Error creating table: " . mysqli_error($conn);
}

// Handle search if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $searchTerm = mysqli_real_escape_string($conn, $_POST['search']);

  // Build search query
  $sql = "SELECT * FROM files WHERE filehash LIKE '%$searchTerm%' OR filename LIKE '%$searchTerm%' OR fileextension LIKE '%$searchTerm%' OR date LIKE '%$searchTerm%' OR wallet LIKE '%$searchTerm%'";

  $result = mysqli_query($conn, $sql);

  if (mysqli_num_rows($result) > 0) {
    echo "<h2>Search Results</h2>";
    echo "<table>
      <thead>
        <tr>
          <th>ID</th>
          <th>File Hash</th>
          <th>Filename</th>
          <th>Extension</th>
          <th>Date</th>
          <th>Invest</th>
        </tr>
      </thead>
      <tbody>";
    while($row = mysqli_fetch_assoc($result)) {
      $rowFileHash = $row["filehash"];
      $rowURL = $row["url"];
      $rowFileName = $row["filename"];
      $rowExtension = $row["fileextension"];

      $localFilePath = 'files/' . $rowFileHash . "." . $rowExtension;

      echo "<tr>
        <td>" . $row["id"] . "</td>
        <td>" . "<a href='$localFilePath' target='_blank'>$rowFileHash</a>" . "</td>
        <td>" . "<a href='$rowURL' target='_blank'>$rowFileName</a>" . "</td>
        <td>" . $row["fileextension"] . "</td>
        <td>" . $row["date"] . "</td>
        <td>" . "<a href='#' class='btn btn-primary'>invest</a>" . "</td>
      </tr>";
    }
    echo "</tbody>
    </table>";
  } else {
    echo "No results found!";
  }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Search Files</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      font-family: 'Roboto', Arial, sans-serif;
      margin: 0;
      padding: 20px;
    }

    h1, h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    form {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }

    .form-group {
      margin-right: 10px;
    }

    .btn {
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      transition: all 0.2s ease-in-out;
      text-decoration: none;
    }

    .btn-primary {
      background-color: #007bff;
      color: white;
    }

    .btn-primary:hover {
      background-color: #0056b3;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <h1>Search Files</h1>
  <form action="" method="post">
    <div class="form-group">
      <input type="text" class="form-control" id="search" name="search" placeholder="Enter search term" required>
    </div>
    <button type="submit" class="btn btn-primary">Search</button>
  </form>
</body>
</html>