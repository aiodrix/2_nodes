<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "aio2nodes";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Create table (if not exists) - for initial setup
$sql = "CREATE TABLE IF NOT EXISTS files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filehash VARCHAR(255) NOT NULL,
  filename VARCHAR(255) NOT NULL,
  filemime VARCHAR(255) NOT NULL,
  filesize VARCHAR(255) NOT NULL,
  fileextension VARCHAR(50) NOT NULL,
  date DATE NOT NULL,
  wallet VARCHAR(255) NOT NULL,
  url VARCHAR(255) DEFAULT NULL
)";

if (mysqli_query($conn, $sql)) {
  //echo "Table files created successfully (or already exists)";
} else {
  echo "Error creating table: " . mysqli_error($conn);
}

// Create 'files' directory if not exists
if (!file_exists("files")) {
  if (!mkdir("files", 0775, true)) {
    die("Failed to create 'files' directory");
  }
}

function getMimeTypeFromContents($data) {
    // Create a Fileinfo resource
    $finfo = finfo_open(FILEINFO_MIME_TYPE);

    // Get the MIME type
    $mimeType = finfo_buffer($finfo, $data);

    // Close the Fileinfo resource
    finfo_close($finfo);

    return $mimeType;
}

function getMimeTypeFromFile($filePath) {
    // Create a Fileinfo resource
    $finfo = finfo_open(FILEINFO_MIME_TYPE);

    // Get the MIME type
    $mimeType = finfo_file($finfo, $filePath);

    // Close the Fileinfo resource
    finfo_close($finfo);

    return $mimeType;
}


function getData($url) {

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  $data = curl_exec($ch);
  curl_close($ch);

  if (!$data) {
    return false;
  }

  return $data;
}

function downloadFile($data, $filehash, $extension) {
   
  $filepath = "files/" . $filehash . "." . $extension;

  if (file_put_contents($filepath, $data)) {
    return $filehash;
  } else {
    return false;
  }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $url = mysqli_real_escape_string($conn, $_POST['url']);
  $wallet = mysqli_real_escape_string($conn, $_POST['wallet']);

  $data = getData($url);

  $filehash = hash('sha256', $data); 

  $filename = basename($url);  

  $extension = pathinfo($filename, PATHINFO_EXTENSION); 

  // Download file and get filename (if successful)
  $filehash = downloadFile($data, $filehash, $extension);

  if ($filehash == ""){
    echo "Error: Failed to download file!";
    die;
  }



  if ($filename) {

    $date = date("Y-m-d");       

    $path = "files/" . $filehash . "." . $extension;

    $filemime = getMimeTypeFromContents($data);

    $filesize = filesize($path);

    // Insert data into database
    $sql = "INSERT INTO files (filehash, filename, filemime, filesize, fileextension, date, url, wallet) VALUES ('$filehash', '$filename','$filemime', '$filesize', '$extension', '$date', '$url', '$wallet')";

    if (mysqli_query($conn, $sql)) {
      echo "File downloaded and information saved successfully!";
    } else {
      echo "Error saving file information: " . mysqli_error($conn);
      // Consider deleting the downloaded file on error
      unlink("files/" . $filename);
    }
  } else {
    echo "Failed to download file!";
  }
}

mysqli_close($conn);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Download File</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background-color: #f5f5f5;
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #333;
    }

    form {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    label {
      margin-bottom: 5px;
      color: #666;
    }

    input[type="url"],
    input[type="text"] {
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      width: 300px;
      margin-bottom: 10px;
      font-size: 16px;
    }

    button {
      padding: 10px 20px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s, transform 0.3s;
    }

    button:hover {
      background-color: #0056b3;
      transform: scale(1.05);
    }
  </style>
</head>
<body>

  <h2>Download File</h2>
  <form action="" method="post">
    <label for="url">File URL:</label>
    <input type="url" id="url" name="url" required>
    <br><br>
    <label for="wallet">Wallet:</label>
    <input type="text" id="wallet" name="wallet" required>
    <br><br>
    <button type="submit">Download and Save</button>
  </form>
  
</body>
</html>