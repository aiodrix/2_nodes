<?php
function zipDirectory($source, $destination) {
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE)) {
        return false;
    }

    $source = realpath($source);
    if (is_dir($source)) {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($source) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
    } else if (is_file($source)) {
        $zip->addFile($source, basename($source));
    }

    return $zip->close();
}

function getZipHash($filePath) {
    $hash = hash_file('sha256', $filePath);
    return $hash;
}

$dir = 'files';
$tempZip = tempnam(sys_get_temp_dir(), 'files_') . '.zip';

if (zipDirectory($dir, $tempZip)) {
    $hash = getZipHash($tempZip);
    $zipFileName = $hash . '.zip';

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipFileName . '"');
    header('Content-Length: ' . filesize($tempZip));

    readfile($tempZip);
    unlink($tempZip); // Remove the temporary file after serving
} else {
    echo json_encode(array('error' => 'Error creating zip file'));
}
?>