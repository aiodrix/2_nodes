package main

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"sync"
)

type Site struct {
	Site        string `json:"site"`
	Description string `json:"description"`
}

func main() {
	var sites []Site

	data, err := ioutil.ReadFile("sites.json")
	if err != nil {
		log.Fatalf("Unable to read sites.json: %v", err)
	}

	err = json.Unmarshal(data, &sites)
	if err != nil {
		log.Fatalf("Error parsing JSON: %v", err)
	}

	sites = removeDuplicates(sites)
	sites = filterOnlineSites(sites)

	updatedData, err := json.MarshalIndent(sites, "", "  ")
	if err != nil {
		log.Fatalf("Error marshaling JSON: %v", err)
	}

	err = ioutil.WriteFile("sites.json", updatedData, 0644)
	if err != nil {
		log.Fatalf("Error writing sites.json: %v", err)
	}

	log.Println("sites.json has been updated successfully.")
}

func removeDuplicates(sites []Site) []Site {
	seen := make(map[string]bool)
	var result []Site

	for _, site := range sites {
		if !seen[site.Site] {
			seen[site.Site] = true
			result = append(result, site)
		}
	}

	return result
}

func filterOnlineSites(sites []Site) []Site {
	var result []Site
	var wg sync.WaitGroup
	var mu sync.Mutex

	for _, site := range sites {
		wg.Add(1)
		go func(s Site) {
			defer wg.Done()
			if isOnline(s.Site) {
				mu.Lock()
				result = append(result, s)
				mu.Unlock()
			}
		}(site)
	}

	wg.Wait()
	return result
}

func isOnline(url string) bool {
	resp, err := http.Get(url)
	if err != nil {
		return false
	}
	defer resp.Body.Close()

	return resp.StatusCode == http.StatusOK
}
